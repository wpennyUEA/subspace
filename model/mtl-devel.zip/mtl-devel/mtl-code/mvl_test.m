function [mvl] = mvl_test (mvl,task,test)
% Compute expected log likelihood of MVL on test set
% FORMAT [mvl] = mvl_test (mvl,task,test)
%
% mvl       data structure
% task      see e.g. rl_task_qlr
% test      .c, .u test set inputs
%
% mvl       .Lexp      expected log likelihood of reward at test
%           .pcexp     expected prob corr (per pattern likelihood) at test
%           

Ntest=length(test.c);
for t=1:Ntest,
    ut=test.u(:,t);
    st=test.s(t);
    [vt,pvt] = mvl_value (mvl,st,ut);
    
    a = rl_decide(vt,mvl.test_lambda);
    [v,pr] = rl_task_reward(task{st},ut,a);
    ell(t) = pr*log(pvt(a)+eps)+(1-pr)*log(1-pvt(a)+eps);
        
%     K=size(mvl.task(st).W,1);
%     for a=1:K,
%         [v,pr] = rl_task_reward(task{st},ut,a);
%         loglike(a) = pr*log(pvt(a)+eps)+(1-pr)*log(1-pvt(a)+eps);
%     end
%     new_ell(t)=loglike*pvt;
end

% sum(ell)
% sum(new_ell)
% 
% mvl.A
% mvl.task(1).W
% keyboard

mvl.Lexp=sum(ell);
mvl.pcexp=exp(mvl.Lexp/Ntest);