function [mvl,removed] = mvl_batch_prune (mvl,n,tau,verbose)
% Prune feature and task mappings
% FORMAT [mvl,removed] = mvl_batch_prune (mvl,n,tau,verbose)
%
% mvl       data struct
% n         task
% tau       memories
% 
% mvl       new MVL model
% removed   1 if row in A was removed, 0 otherwise

if nargin < 4 | isempty(verbose), verbose=0; end

logBF_threshold=log(10);
%logBF_threshold=log(20);

opt.alg = 'LineSearch';
opt.verbose = 0;
opt.W_first = 1;
model = mvl_log_evidence (mvl,n,tau);
    
[F,D] = size(mvl.A);
for f=1:F,
    tmp{f}=mvl;
    % Prune feature matrix
    tmp{f}.A(f,:)=[];
    
    % Prune task mapping
    % tmp{f}.m(f,:)=[];

    % Prune and Reposition RBF centres
    %rbf = mvl_rbf_centres_tile (F-1);
    %tmp{f}.m = rbf.m;
    %tmp{f}.beta = rbf.beta;
    
    % Prune RBF centres
    tmp{f}.m(f,:)=[];
    
    % Update params of reduced model
    tmp{f} = mvl_batch_learn (tmp{f},n,tau,opt);
    
    tmp_model = mvl_log_evidence (tmp{f},n,tau);
    
    %logbf_new = mvl_log_BF (mvl,n,tau)

    reduced.logev(f) = tmp_model.logev;
    reduced.loglike(f) = tmp_model.loglike;
end

% Log Bayes Factors
logbf=reduced.logev-model.logev;
[maxlogbf,ind]=max(logbf);
if maxlogbf > logBF_threshold
    disp(sprintf('Removing row, LogBF=%1.2f',maxlogbf));
    mvl=tmp{ind};
    removed=1;
else
    removed=0;
end

if verbose
    disp(' ');
    disp('Statistical tests for removing rows - reduced versus full:');
    disp(' ');
    disp('LogBF:');
    disp(logbf);
    disp('LogLF:');
    disp(reduced.loglike-model.loglike);
end
