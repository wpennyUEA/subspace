function [params] = mvl_default_params ()
% Default parameters for MVL 

params.D=4;                     % Input Dimension
params.F=4;                     % Initial Feature Dimension
params.train_lambda=1;          % Decision noise for training
params.test_lambda=1;           % Decision noise for testing
params.alpha_w=0.3;             % Online learning rate for W 
params.alpha_a=0.1;             % Online learning rate for A 
params.verbose=1;               % Plot graphs & text output


% RBF params
params.rbf_centres='fixed';    % Fixed or Constructive RBF centres ?
%params.rbf_centres='constr';    % Fixed or Constructive RBF centres ?
%params.h_thresh=0.5;            % Add a new RBF unit if max(h) under this threshold 
params.h_thresh=0.01;            % Add a new RBF unit if max(h) under this threshold 
params.rbf_s0=1.1;                  % Initial StandardDev of Gaussian RBFs

% MVL Online 
%params.onlinealg='LineSearch';  
params.onlinealg='FixedStepSize';  

% MVL Offline
params.pc_thresh=0.70;          % likelihood threshold for multistart algorithm
params.offline_init='RBF-Online';      % How to initialise MVL-Offline ?

% Bayesian estimation and inference
params.rho=1;                   % Prior precision over A
params.eta=1;                   % Prior precision over W
params.maxpost=1;               % Max posterior learning for A
params.alpha_anneal=0.1;           % Annealing rate for loosening prior
%params.alpha_anneal=0.01;           % Annealing rate for loosening prior
%params.alpha_anneal=0.001;           % Annealing rate for loosening prior

% JDM Online
params.s0=1.1;                  % Initial StandardDev of Gaussian RBFs
params.p0=0.001;                % New cluster threshold in jdm_learn.m

% RMS-Prop with Momentum
params.rmsn_alpha = 0.2;        % Learning rate for RMSN
params.rmsn_delta = 1e-6;       % Small number for RMSN
params.rmsn_beta = 0;           % Momentum for RMSN
params.rmsn_rho = 0.5;          % Accumulation of squared gradients