function [L,dLdA,dLdW,dLdv,Hs] = log_like_sample (mvl,n,u,a,r)
% Compute log likelihood of MVL model
% FORMAT [L,dLdA,dLdW,dLdv,Hs] = log_like_sample (mvl,n,u,a,r)
%
% mvl       mvl data structure
% n         task index
% u         input
% a         action/decision
% r         reward
%
% L         log likelihood
% dLdA      derivative wrt feature matrix A
% dLdW      derivative wrt task matrix W
% dLdv      derivative wrt value vector
% Hs        contribution to Hessian (analytic evaluation - not working !)

if nargout > 1
    [v,pv,hh,xx,dvdA,GT] = mvl_value (mvl,n,u);
else
    [v,pv] = mvl_value (mvl,n,u);
end

d=a;
rpe = r - pv(d);
uncert = pv(d)*(1-pv(d));
L = r*log(pv(d)+eps)+(1-r)*log(1-pv(d)+eps);

[F,D]=size(mvl.A);
[K,P]=size(mvl.task(n).W);
if nargout > 1
    
    dLdA = zeros(F,D);
    for k=1:K,
        if k==d,
            dpvdv = pv(d)*(1-pv(d));
        else
            dpvdv = -pv(d)*pv(k);
        end
        dLdA = dLdA + rpe * dpvdv * dvdA{k} / uncert;
        dLdv(k) = rpe * dpvdv / uncert;
    end
    
    dLdW = zeros(K,P);
    for k=1:K,
        if k==d,
            dpvdv = pv(d)*(1-pv(d));
        else
            dpvdv = -pv(d)*pv(k);
        end
        dLdW(k,:)= rpe * dpvdv * hh' / uncert;
    end
    
    dpvdv=zeros(K,1);
    for k=1:K,
        if k==d,
            dpvdv(k) = pv(d)*(1-pv(d));
        else
            dpvdv(k) = -pv(d)*pv(k);
        end
    end
    Hsamp=GT*dpvdv;
    for f=1:F,
        Hs(:,:,f)=-(rpe/uncert)*Hsamp(f)*u*u';
    end
 end
