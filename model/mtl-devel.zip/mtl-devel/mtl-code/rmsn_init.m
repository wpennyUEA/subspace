function [rmsn] = rmsn_init (mvl)
% RMS Prop with Nesterov momentum - initialisation
% FORMAT [rmsn] = rmsn_init (mvl)
%
% mvl       data structure
%
% rmsn      accumulated quantities
%               .r  squared gradient
%               .v  accumulated gradient

theta = mvl_vec_params(mvl);
P = length(theta);
rmsn.r = zeros(P,1);
rmsn.v = zeros(P,1);