function [E] = mvl_tune_alpha (alpha,mvl,tau,dLdA)
% Evaluate negative log likelihood (error) 
% FORMAT [E] = mvl_tune_alpha (alpha,mvl,tau,dLdA)
%
% alpha     Step size
% mvl       mvl data structure
% tau       memory buffer
% dLdA      Gradient
%
% E         Negative log likelihood (error)

mvl.A = mvl.A + alpha*dLdA;
Ls = mvl_sum_log_like (mvl,tau);

if mvl.maxpost
    logPA = mvl_log_prior (mvl);
    Ls = Ls + logPA;
end

E = -Ls;