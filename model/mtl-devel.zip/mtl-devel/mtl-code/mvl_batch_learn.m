function [mvl] = mvl_batch_learn (mvl,tau,opt)
% MVL batch learning algorithm
% FORMAT [mvl] = mvl_batch_learn (mvl,tau,opt)
%
% mvl       data structure
%               .maxits  default is 32
%               .tol default is 0.01
% tau       memories
% opt       optimisation settings
%               .verbose 0/1 (default 0)
%               .W_first  0/1 (default 0) 1 to update W first
%
% mvl       updated with
%           .loglike
%           .pc
%           .Ltraj
%           .Atraj{f} evolution of fth row of A

if isfield(opt,'W_first') W_first=opt.W_first; else W_first=0; end
if isfield(opt,'verbose') verbose=opt.verbose; else verbose=0; end
if isfield(mvl,'maxits') maxits=mvl.maxits; else maxits=32; end
if isfield(mvl,'tol') tol=mvl.tol; else tol=0.01; end

T=length(tau.r);

% Update MVL 
[F,D]=size(mvl.A);

% For debugging
update_W=1;
update_A=1;

N=length(mvl.task);

i=1;
if W_first
    for n=1:N,
        [mvl,Lsum(i)] = mvl_update_W (mvl,n,tau,opt);
    end
    i=i+1;
    if verbose, disp(sprintf('Iteration %d, W Update, LogLike=%1.2f',i,Lsum(i-1))); end
end
    
for it=1:maxits,
    
    for f=1:F,
        Atraj{f}(it,:)=mvl.A(f,:);
    end
    
    if update_A
        [mvl,Lsum(i)] = mvl_update_A (mvl,tau,opt);
        i=i+1;
        if verbose, disp(sprintf('Iteration %d, A Update, LogLike=%1.2f',it,Lsum(i-1))); end
    end
    
    if update_W
        for n=1:N,
            if any(tau.s==n)
                % If any exemplars of task n then update relevant W
                [mvl,Lw(n)] = mvl_update_W (mvl,n,tau,opt);
            end
        end
        %Lsum(i)=sum(Lw);
        %i=i+1;
        %if verbose, disp(sprintf('Iteration %d, W Update, LogLike=%1.2f',it,Lsum(i-1))); end
    end
    
    if it > 8
        if abs((Lsum(i-1)-Lsum(i-2))/Lsum(i-1)) < tol
            break;
        end
    end
  
end

mvl.Ltraj=Lsum;
mvl.loglike=Lsum(end);
mvl.pc=exp(mvl.loglike/T);
mvl.Atraj=Atraj;
mvl.its=it;

