function [net] = run_simulation (sim,run,task,mvl)
% Fit networks to a data set and report train/test likelihood
% FORMAT [net] = run_simulation (sim,run,task,mvl)
%
% sim       simulation structure
% run       which models to fit         
% task      which task(s) we're using to produce rewards
% mvl       with various parameters set
%
% net{i}    net{i}.mvl is ith fitted MVL model 
%
% See e.g. Experiment3.m for an example of how to use

train=sim.train;
test=sim.test;
verbose=0;
F=mvl.F;

i=1;

if ~isfield(run,'mvl_rbf'), run.mvl_rbf=0; end
if ~isfield(run,'mvl_online'), run.mvl_online=0; end
if ~isfield(run,'jdm_online'), run.jdm_online=0; end
if ~isfield(run,'mvl_offline'), run.mvl_offline=0; end
if ~isfield(run,'mvl_pruning'), run.mvl_pruning=0; end

if run.mvl_rbf
    mvl_rbf=mvl;
    [mvl_rbf,tau_rbf] = mvl_rbf_learn (mvl,task,train);
    if verbose
        figure
        hinton(mvl_rbf.A);
        title('MVL RBF');
    end
    mvl_rbf = mvl_test(mvl_rbf,task,test);
    net{i}.mvl=mvl_rbf;
    net{i}.name='RBF-Online';
    i=i+1;
    
    if strcmp(mvl.offline_init,'RBF-Online'),
        disp('Exact Replay: RBF-Online');
        tau=tau_rbf;
    end
end

if run.mvl_online
    mvl_online=mvl;
    mvl_online.updateA=1;
    [mvl_online,tau_online] = mvl_online_learn (mvl_online,task,train);
    if verbose
        figure
        hinton(mvl_online.A);
        title('MVL Online');
    end
    mvl_online = mvl_test(mvl_online,task,test);
    net{i}.mvl=mvl_online;
    net{i}.name='MVL-Online';
    i=i+1;
    if strcmp(mvl.offline_init,'MVL-Online'),
        disp('Exact Replay: MVL-Online');
        tau=tau_online;
    end
end

if run.jdm_online
    jdm.s0 = mvl.s0;
    jdm.p0 = mvl.p0;
    jdm = jdm_learn (jdm,tau_rbf);
    jdm = jdm_test(jdm,task,train);
    jdm.L = jdm.Lexp;
    jdm.pc = jdm.pcexp;
    jdm = jdm_test(jdm,task,test);
    net{i}.mvl=jdm;
    net{i}.name='JDM-Online';
    i=i+1;
    Ntrain=length(tau_rbf.r)*mvl.replay_factor;
    tau_jdm = jdm_sample(jdm,Ntrain);
    tau_jdm.r = tau_jdm.r - 1;
    tau_jdm.s = ones(1,Ntrain);
    if strcmp(mvl.offline_init,'JDM-Online'),
        disp(sprintf('Generative Replay x %d',mvl.replay_factor));
        tau=tau_jdm;
    end
end

if run.mvl_offline
    m=mvl_rbf.m(1:F,:);
    mvl_rbf.m=m;
    [mvl_offline,restarts] = mvl_batch_restart (mvl_rbf,tau,mvl.F);
    R=length(restarts);
    mvl_offline.num_restarts=R;
    if verbose
        figure
        plot(mvl_offline.Ltraj);
        grid on
        
        figure;plot(mvl_offline.Atraj{1});
        grid on
        xlabel('Iteration');
        ylabel('A(1,:)');
        
        figure
        hinton(mvl_offline.A);
        title('MVL Offline');
    end
    mvl_offline = mvl_test(mvl_offline,task,test);
    net{i}.mvl=mvl_offline;
    net{i}.name='MVL-Offline';
    i=i+1;
end

% Keep removing rows in greedy pruning search
if run.mvl_pruning
    mvl_pruned=mvl_offline;
    removed=1;
    while removed & F > 1
        [mvl_pruned,removed] = mvl_prune_features (mvl_pruned,tau,1);
        F = size(mvl_pruned.A,1);
    end
    if verbose
        figure
        hinton(mvl_pruned.A);
        title('MVL Pruned');
    end
    mvl_pruned=mvl_test(mvl_pruned,task,test);
    net{i}.mvl=mvl_pruned;
    net{i}.name='MVL-Pruned';
    i=i+1;
end

for j=1:length(net)
    net{j}.train_pc=net{j}.mvl.pc;
    net{j}.test_pc=net{j}.mvl.pcexp;
end
    