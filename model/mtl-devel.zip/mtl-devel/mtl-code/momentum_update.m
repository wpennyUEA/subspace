function [mvl,rmsn] = momentum_update(mvl,rmsn,g)
% Gradient update with Momentum
% FORMAT [mvl,rmsn] = momentum_update(mvl,rmsn,g)
%
% mvl       data structure
%               .rmsn_alpha Learning rate 
%               .rmsn_beta Momentum parameter
% rmsn      accumulated quantities
%               .v  accumulated gradient
% g         sample gradient

alpha = mvl.rmsn_alpha;
beta = mvl.rmsn_beta;

rmsn.v = beta*rmsn.v + alpha*g;

theta = mvl_vec_params (mvl);
theta = theta + rmsn.v;
mvl = mvl_unvec_params (mvl,theta);