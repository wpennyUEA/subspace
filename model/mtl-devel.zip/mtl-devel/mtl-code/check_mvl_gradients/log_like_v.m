function [L,dLdv] = log_like_v (mvl,v,a,r)
% Compute log likelihood as a function of v
% FORMAT [L,dLdv] = log_like_v (mvl,v,a,r)

K = length(v);
pv = exp(v);
pv = pv/sum(pv);
d=a;
rpe = r - pv(d);
uncert = pv(d)*(1-pv(d));
L = r*log(pv(d)+eps)+(1-r)*log(1-pv(d)+eps);


if nargout > 1
    
    for k=1:K,
        if k==d,
            dpvdv = pv(d)*(1-pv(d));
        else
            dpvdv = -pv(d)*pv(k);
        end
        dLdv(k) = rpe * dpvdv / uncert;
    end
    
end
