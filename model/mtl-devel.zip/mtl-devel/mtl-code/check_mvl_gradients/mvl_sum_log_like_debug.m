function [Lsum,dLdA] = mvl_sum_log_like (mvl,n,tau)
% Return batch log likelihood 
% FORMAT [Lsum,dLdA] = mvl_sum_log_like (mvl,n,tau)
%
% mvl       data structure
% n         task index
% tau       memory structure
%
% Lsum      batch log likelihood
% dLdA      gradient

[F,D]=size(mvl.A);
dLdA=zeros(F,D);
T=length(tau.a);
A=mvl.A;
for t=1:T,
    u=tau.u(:,t);
    a=tau.a(t);
    r=tau.r(t);
    
    for k=1:2,
        [v(k),dvdA{k}] = mvl_value_A (mvl,n,u(:,t),k,A);
        dvdA{k}
        
        dv_dA_num{k} = spm_diff('mvl_value_A',mvl,n,u(:,t),k,A,5);
        dv_dA_num{k}
    end
    
%     [L,dLdv] = log_like_v (mvl,v,a,r);
%     dLdv
%     
%     dLdv_num = spm_diff('log_like_v',mvl,v,a,r,2);
%     dLdv_num
    
    
    
    [L(t),dLdA_eq,dLdW,dLdv] = log_like_A (mvl,n,u,a,r,A);
    
    if nargout > 1
        dL_dA_num = spm_diff('log_like_A',mvl,n,u,a,r,A,6);
        dLdA = dLdA + full(dL_dA_num);
        
        dLdA_eq
        full(dL_dA_num)
        keyboard
    end
end
Lsum=sum(L);
