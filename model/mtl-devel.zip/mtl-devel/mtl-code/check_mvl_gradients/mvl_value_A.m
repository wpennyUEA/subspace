function [vk,dvkdA] = mvl_value_A (mvl,n,ut,ki,A)
% Return values from Modular Value Learning network
% FORMAT [vk,dvkdA] = mvl_value_A (mvl,n,ut,ki,A)
%
% mvl       Data Structure
%           .A      [F x D] Encoding Matrix
%           .m      [F x P] basis function means
%           .beta   [P x 1] basis function precisions
%           .task(n).W      [K x P] Task Mapping
% n         task index
% ut        [D x 1] current input
% k         output
% A         A matrix
%
% v         values of current input for decision k
% dvkdA     Derivative dvk_dA

x = A*ut;
h = mvl_rbf (mvl,x);
vt = mvl.task(n).W*h;
pvt = exp(vt);
pvt = pvt/sum(pvt);

vk=vt(ki);
if nargout < 2
    return
end

% Compute derivatives

[F,P] = size(mvl.m);
K = size(mvl.task(n).W,1);
for k=1:K,
    gt=zeros(F,1);
    for p=1:P,
        gt = gt + mvl.task(n).W(k,p)*h(p)*mvl.beta(p)*(mvl.m(:,p)-x);
    end
    dvdA{k}=gt*ut';
end

dvkdA=dvdA{ki};