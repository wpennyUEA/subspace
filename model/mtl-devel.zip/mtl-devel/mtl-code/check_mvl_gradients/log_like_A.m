function [L,dLdA,dLdW,dLdv] = log_like_A (mvl,n,u,a,r,A)
% Compute log likelihood as a function of A
% FORMAT [L,dLdA,dLdW,dLdv] = log_like_A (mvl,n,u,a,r,A)

mvl.A=A;
if nargout > 1
    [v,pv,hh,xx,dvdA] = mvl_value (mvl,n,u);
else
    [v,pv] = mvl_value (mvl,n,u);
end

d=a;
rpe = r - pv(d);
uncert = pv(d)*(1-pv(d));
L = r*log(pv(d)+eps)+(1-r)*log(1-pv(d)+eps);

[F,D]=size(A);
[K,P]=size(mvl.task(n).W);
if nargout > 1
    
    % This code is wrong
    dLdA = zeros(F,D);
    for k=1:K,
        if k==d,
            dpvdv = pv(d)*(1-pv(d));
        else
            dpvdv = -pv(d)*pv(k);
        end
        dLdA = dLdA + rpe * dpvdv * dvdA{k} / uncert;
        dLdv(k) = rpe * dpvdv / uncert;
    end
    
    dLdW = zeros(K,P);
    for k=1:K,
        if k==d,
            dpvdv = pv(d)*(1-pv(d));
        else
            dpvdv = -pv(d)*pv(k);
        end
        dLdW(k,:)= rpe * dpvdv * hh';
    end
    
end
