
clear all
close all

load debug_A0

mvl_like_Ak(mvl,n,tau,1,mvl.A(1,:));

mvl_like_Ak(mvl,n,tau,1,zeros(1,2));

T=length(tau.r);
for t=1:T,
    [v1,pv1,hh1,xx1] = mvl_value (mvl,n,tau.u(:,t));
    
    zmvl = mvl;
    zmvl.A(1,:) = zeros(1,2);
    
    [v,pv,hh,xx] = mvl_value (zmvl,n,tau.u(:,t));
    
    model.pv(:,t)=pv1;
    reduced.pv(:,t)=pv;
end

figure
plot(model.pv(1,:),reduced.pv(1,:),'o');
grid on
xlabel('Value prob from full model');
ylabel('Value prob from reduced model');

return
disp([xx1,xx]);
disp([hh1,hh]);
disp([v1,v]);
disp([pv1,pv]);