
clear all
close all

load mvl_grad_debug
mvl.task(1).W = [mvl.task(1).W,[0.1 0.2]']; % Add column for (new) constant term
A=mvl.A;

t=151;
[v,dv1dA] = mvl_value_A (mvl,n,u(:,t),A);
dv1dA

dv1_dA_num = spm_diff('mvl_value_A',mvl,n,u(:,t),A,4);
full(reshape(dv1_dA_num(:),2,2))