
clear all
close all

load results/expt3-11-52

z=1;
for i=1:4,
    for j=1:10,
        a(z)=res(i,j).net{3}.train_pc;
        b(z)=res(i,j).net{1}.train_pc;
        c(z)=res(i,j).net{3}.test_pc;
        d(z)=res(i,j).net{1}.test_pc;
        z=z+1;
    end
end
figure
plot(b,a,'x');
xlabel('RBF Online Train Like');
ylabel('MVL Offline Train Like');
corrcoef(a,b)

figure
plot(d,c,'x');
xlabel('RBF Online Test Like');
ylabel('MVL Offline Test Like');
corrcoef(c,d)