function [mvl] = mvl_rbf_init (mvl,u,nbasis)
% Create RBF units
% FORMAT [mvl] = mvl_rbf_init (mvl,u,nbasis)
%
% mvl       data structure
% u         input data
% nbasis    number of RBF units
%
% mvl       data structure 
%               .m    RBF means 
%               .beta RBF precisions
%

x=mvl.A*u;
[priors,means]=spm_kmeans(x',nbasis);
mvl.m=means';
mvl.beta=0.25*ones(1,nbasis);

verbose=0;
if verbose
    x=mvl.m(1,:);
    y=mvl.m(2,:);
    figure
    plot(x,y,'x');
    %xlim([0 6]);
    %ylim([0 6]);
    
    [D,T]=size(u);
    for t=1:T,
        ut=u(:,t);
        xt = mvl.A*ut;
        h(:,t) = mvl_rbf (mvl,xt);
    end
    figure
    imagesc(h);
    colorbar
    xlabel('Trial');
    ylabel('RBF unit');
    keyboard
end
