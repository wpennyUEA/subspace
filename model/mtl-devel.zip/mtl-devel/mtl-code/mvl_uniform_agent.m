function [mvl,tau] = mvl_uniform_agent (mvl,rl_task,train)
% Make decisions from uniform distribution and fill memory buffer 
% FORMAT [mvl,tau] = mvl_uniform_agent (mvl,rl_task,train)
%
% mvl       data structure
% rl_task   task
% train     training data

u = train.u;
s = train.s;

N=length(rl_task);
for n=1:N,
    K(n)=rl_task{n}.K;
end

[D,T] = size(u);
F = mvl.F;

if ~isfield(mvl,'A')
    mvl.A = randn(F,D);
end

% Initialise RBF units
%tmp = mvl_rbf_centres_tile (F);
%mvl.beta=tmp.beta;
%mvl.m=tmp.m;
Nbasis=9;
mvl = mvl_rbf_init (mvl,train.u,Nbasis);

P = length(mvl.beta)+1;
for n=1:N,
    mvl.task(n).W=randn(K(n),P);
end

% Define empty memory buffer
tau.u=[]; tau.a=[]; tau.r=[]; tau.s=[];

% Prior mean and precision over rows of A
mvl.m0=zeros(F,D);
for f=1:F,
    mvl.Lambda0(:,:,f)=mvl.rho*eye(D);
end

% Initial Period has Uniform Distribution over Actions
for t=1:mvl.Cinit,
    ut = u(:,t);
    st = s(t);
    pa=ones(K(st),1)/K;
    a(t) = spm_multrnd(pa,1);
    [vtrue,pr(t),r(t)] = rl_task_reward (rl_task{st},ut,a(t));
    
    % Add trial data to memory buffer
    tau.u=[tau.u,ut];
    tau.a=[tau.a,a(t)];
    tau.r=[tau.r,r(t)];
    tau.s=[tau.s,st];
end

pa=length(find(tau.a==1))/mvl.Cinit;
disp(sprintf('Sequential Updating from %d samples, pa=%1.2f',mvl.Cinit,pa));