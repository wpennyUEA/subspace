
clear all
close all

load results/expt3-11-52
i=4;
figure

k=3;

for j=1:9,
    subplot(3,3,j);
    x=res(i,j).net{k}.mvl.m(1,:);
    y=res(i,j).net{k}.mvl.m(2,:);
    pc=res(i,j).net{k}.test_pc;
    plot(x,y,'x');
    name=res(i,j).net{k}.name;
    title(sprintf('%s Test PC = %1.2f',name,pc));
end

k=4;

figure
for j=1:9,
    subplot(3,3,j);
    x=res(i,j).net{k}.mvl.m(1,:);
    [F,P]=size(res(i,j).net{k}.mvl.m);
    pc=res(i,j).net{k}.test_pc;
    plot(x,zeros(1,P),'x');
    name=res(i,j).net{k}.name;
    title(sprintf('%s F=%d Test PC = %1.2f',name,F,pc));
end
