
close all
clear all

task{1} = rl_task_qlr (0,1); % Sub1
task{2} = rl_task_lr (0,1);  % Sub2
task{3} = rl_task_qlr (1,1); % Add1
task{4} = rl_task_lr (1,1);  % Add2

for i=1:4,
    for j=1:4,
        ri=task{i}.y;
        rj=task{j}.y;
        dr(i,j)=mean(mean(abs(ri-rj)));
    end
end

crossover=1-dr;
disp(crossover)