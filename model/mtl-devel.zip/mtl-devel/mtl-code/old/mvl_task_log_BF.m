function [logBF,reduced,debug] = mvl_task_log_BF (mvl,n,tau)
% Compute Log Bayes Factors over Task Matrix
% FORMAT [logBF,reduced,debug] = mvl_task_log_BF (mvl,n,tau)
%
% mvl       data struct
% n         task
% tau       memories
% 
% logBF     Entry (p) is for column p of task(n).W
% reduced   Cell of reduced models
% debug     Debug info
%           .acc_diff   differeence in log likelihoods
%           .log_prior_diff difference in log priors

% Log Likelihood
LLa = mvl_sum_log_like (mvl,n,tau);

% Log Priors
[logPA,logPW] = mvl_log_prior (mvl,n);

% Log Joint
J = LLa + logPW;

opt.alg = 'LineSearch';
opt.verbose = 0;

[K,P]=size(mvl.task(n).W);
for p=1:P-1,
    % Remove column p
    tmp_mvl = mvl; tmp_mvl.task(n).W(:,p) = [];
    
    % Prune RBF centres
    tmp_mvl.m(:,p)=[];
    
    % Retune other W's
    tmp_mvl = mvl_update_W (tmp_mvl,n,tau,opt);
    
    [tmp,lpw] = mvl_log_prior (tmp_mvl,n);
    loglike = mvl_sum_log_like (tmp_mvl,n,tau); 
    Jred = loglike+lpw;
    
    wp = mvl.task(n).W(:,p);
    H = spm_diff ('mvl_like_wp',mvl,n,tau,p,wp,[5 5]);
    iC = -full(H)+mvl.eta*eye(K);
    ldC = spm_logdet(iC);
    logBF(p) = Jred-J+0.5*ldC-0.5*K*log(2*pi);
    
    debug.acc_diff(p) = loglike-LLa;
    debug.log_prior_diff(p) = lpw-logPW;
    debug.Cp{p} = inv(iC);
    
    reduced{p}=tmp_mvl;
end

