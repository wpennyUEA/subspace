
clear all
close all

%task = rl_task_qlr (0,1);
task = rl_task_qlr (1,1);

T=50;
s=ones(T,1);

% Generate cue sequence over whole experiment
S=task.S;
K=task.K;
C=S^2;
u1=ones(C,1)/C;
c=spm_multrnd(u1,T);  % categorical/configural representation of input
for t=1:T,
    u(:,t)=task.u(:,c(t)); % continuous/integer representation of input
end
D=size(u,1);

config.alpha=0.3;
config.lambda=10;
config.verbose=1;

[config,tau] = config_learn(config,task,c);

n = 1;
for F=1:D,
    mvl{F} = mvl_batch_restart (n,tau,F);
    mvl_model = mvl_log_evidence (mvl{F},n,tau);
    LogEv(F)=mvl_model.logev;
    LogLike(F)=mvl_model.loglike;
    LogPrior(F)=mvl_model.logprior;
end


LogEv=LogEv-min(LogEv);
LogLike=LogLike-min(LogLike);
LogPrior=LogPrior-min(LogPrior);

figure
subplot(2,2,1);
bar(LogEv);
grid on
xlabel('F');
ylabel('Log Model Evidence');

subplot(2,2,2);
bar(LogLike);
grid on
xlabel('F');
ylabel('Log Likelihood');

subplot(2,2,3);
bar(LogPrior);
grid on
xlabel('F');
ylabel('Log Prior');
