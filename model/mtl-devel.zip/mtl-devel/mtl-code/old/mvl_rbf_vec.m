function [h] = mvl_rbf_vec (mvl,x)
% Get RBF output
% FORMAT [h] = mvl_rbf_vec (mvl,x)
%
% mvl       Data Structure
%           .m      [F x (P-1)] basis function means
%           .beta   [(P-1) x 1] basis function precisions
% x         [F x 1] Feature vector
%
% h         RBF outputs

F = length(x);
e = x-mvl.m;
if F > 1
    d = 0.5*sum(e.*e).*mvl.beta;
else
    d = 0.5*(e.*e).*mvl.beta;
end
h = exp(-d)';
h = [h; 1];

