
clear all
close all

task{1} = rl_task_qlr (0,1);
%task{1} = rl_task_qlr (1,1);

mvl = mvl_default_params ();

reps.train=6;
reps.test=10;
[train,test] = rl_task_set_fixed (task{1},reps,mvl.D);
train.s=ones(1,train.N);
test.s=ones(1,test.N);

T=train.N;           % Number of trials
mvl.F=1;
mvl.gamma_rpe=0;

% Fit Single Model
disp(' ');
disp('Single Episode Model:');
mvl_ep1=mvl;
mvl_ep1.episodes=1;
mvl_ep1 = mvl_sequential (mvl_ep1,task,train);
mvl_rbf = mvl_test(mvl_ep1.rbf_solution,task,test);
test_like_RBF=mvl_rbf.pcexp;
disp(' ');
disp(sprintf('TestLike RBF = %1.2f',test_like_RBF));
disp(' ');
mvl_ep1 = mvl_test(mvl_ep1,task,test);
test_like=mvl_ep1.pcexp;
disp(' ');
disp(sprintf('TestLike = %1.2f',test_like));
disp(' ');

% Fit Two-Episode Model
disp(' ');
disp('Two-Episode Model:');
mvl_ep2=mvl;
mvl_ep2.episodes=2;
mvl_ep2 = mvl_sequential (mvl_ep2,task,train);
mvl_rbf2 = mvl_test(mvl_ep2.rbf_solution,task,test);
test_like_RBF=mvl_rbf2.pcexp;
disp(' ');
disp(sprintf('TestLike RBF = %1.2f',test_like_RBF));
disp(' ');
mvl_ep2 = mvl_test(mvl_ep2,task,test);
test_like=mvl_ep2.pcexp;
disp(' ');
disp(sprintf('TestLike = %1.2f',test_like));
disp(' ');

return

chain = mvl.chain;
chains = length(chain);
for c=1:chains,
    mvl.A=mvl.chain(c).postA(end).mp;
    mvl = mvl_test(mvl,task,test);
    disp(sprintf('Chain %d Test Likelihood %1.2f', c, mvl.pcexp));
    for i=1:episodes,
        chain(c).m(:,i)=chain(c).postA(i).mp(1,:);
        chain(c).s(:,i)=chain(c).postA(i).Asd(1,:);
    end
    chain(c).pcexp=mvl.pcexp;
end


figure
for c=1:chains,
    subplot(3,3,c);
    col={'k-','b-','r-','g-','c-'};
    name={'a_{11}','a_{12}','a_{13}','a_{14}'};
    for d=1:4,
        errorbar(chain(c).m(d,:),chain(c).s(d,:),col{d});
        hold on
        grid on
    end
    legend(name);
    xlim([0.9 episodes+0.1]);
    xlabel('Update');
    ylabel('Parameter Estimate');
    xlabel('Update');
    title(sprintf('Chain %d Test Like = %1.2f',c,chain(c).pcexp));
end

for c=1:chains,
    testlike(c)=chain(c).pcexp;
    like(1,c)=chain(c).loglike(1);
    if episodes > 1
        like(2,c)=chain(c).loglike(2);
        like(3,c)=like(1,c)+like(2,c);
        Rplot=3;
    else
        Rplot=1;
    end
end

name={'Like 1', 'Like 2', 'Sum Like'};
figure
for i=1:Rplot,
    subplot(2,2,i);
    plot(like(i,:),testlike,'x');
    xlabel(name{i});
    ylabel('Test Likelihood');
    cc=corrcoef(like(i,:),testlike);
    r=cc(1,2);
    title(sprintf('Corr = %1.2f',r));
end

E=length(mvl.episode);
figure
for e=1:E,
    subplot(2,1,e);
    plot_tau (mvl.episode(e).tau);
end

