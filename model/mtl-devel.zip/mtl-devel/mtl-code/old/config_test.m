function [config] = config_test (config,task,test,lambda)
% Compute expected log likelihood of Config RL on test set
% FORMAT [config] = config_test (config,task,test,lambda)
%
% config        data structure
% task          see e.g. rl_task_qlr
% test          .c, .u test set inputs
%
% config        .Lexp   expected log likelihood of reward

if nargin < 4 | isempty(lambda);
    lambda=10;
end

Ntest=length(test.c);
for t=1:Ntest,
    ut=test.u(:,t);
    ct=test.c(t);
    vt=config.Qmat(ct,:);
    a = rl_decide(vt,lambda);
    [v,pr] = rl_task_reward(task,ut,a);
    ell(t) = pr*log(vt(a)+eps)+(1-pr)*log(1-vt(a)+eps);
end

config.Lexp=sum(ell);