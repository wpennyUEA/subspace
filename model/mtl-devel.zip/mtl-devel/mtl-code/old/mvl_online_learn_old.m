function [mvl,tau] = mvl_online_learn (mvl,rl_task,train)
% MVL Online Learning
% FORMAT [mvl,tau] = mvl_online_learn (mvl,rl_task,train)
%
% mvl           data structure
%                   .alpha  learning rate
%                   .train_lambda decision noise
%                   .verbose (0/1) default is 0
% rl_task       task data structure
% train         training data structure
%                   .u   [D x T] vector of inputs
%                   .s   [1 x T] task vector
%
% mvl           data structure
%                   .loglike    log likelihood of rewards
%                   .pc         prob correct (=exp(.loglike/T))
% tau           data for training MVL-offline
%                   .u      inputs
%                   .a      actions
%                   .r      rewards
%                   .s      task indices

if isfield(mvl,'verbose'),verbose=mvl.verbose; else verbose=0; end

u = train.u;
s = train.s;

N=length(rl_task);
for n=1:N,
    K(n)=rl_task{n}.K;
end

[D,T] = size(u);
F = mvl.F;

if ~isfield(mvl,'A')
    mvl.A = randn(F,D);
end

if strcmp(mvl.rbf_centres,'fixed')
    fixed_centres=1;
    if ~isfield(mvl,'m')
        tmp = mvl_rbf_centres_tile (F);
        mvl.beta=tmp.beta;
        mvl.m=tmp.m;
    end
    P = length(mvl.beta)+1;
    for n=1:N,
        mvl.task(n).W=randn(K(n),P);
    end
else
    fixed_centres=0;
end

beta=1;
loglike=0;
P_max=12;

for t=1:T,
    
    ut = u(:,t);
    st = s(t);
    
    if t==1 & fixed_centres==0
        xt = mvl.A*ut;
        mvl.m=xt;
        mvl.beta=beta;
        P=2;
        for n=1:N,
            mvl.task(n).W=randn(K(n),P);
        end
    end
    [vt,pvt,h,xt] = mvl_value (mvl,st,ut);
    
    % Make decision
    a(t) = rl_decide(vt,mvl.train_lambda);
    
    % Get reward
    d = a(t);
    [vtrue,pr(t),r(t)] = rl_task_reward (rl_task{st},ut,d);
     
    % Value (expected reward prob) of chosen option
    pi_d=pvt(d);
    loglike = loglike + r(t)*log(pi_d+eps) + (1-r(t))*log(1-pi_d+eps);
    
    hmax(t)=max(h(1:P-1));
    
    if fixed_centres==0
        if (hmax(t) < mvl.h_thresh) & (P < P_max+1)
            %disp('Creating new basis function ...');
            mvl.m=[mvl.m,xt];
            mvl.beta=[mvl.beta,beta];
            for n=1:N,
                % Increase dimension of all W matrices
                Wconst=mvl.task(n).W(:,P);
                W=mvl.task(n).W(:,1:P-1);
                Wnew=randn(K(n),1);
                mvl.task(n).W=[W,Wnew,Wconst];
            end
            P = P+1;
        end
    end
    
    switch mvl.onlinealg,
        case 'FixedStepSize',
            % Update task weights
            [L,dLdA,dLdW] = log_like_sample (mvl,st,ut,d,r(t));
            mvl.task(st).W = mvl.task(st).W + mvl.alpha_w * dLdW;
            if mvl.updateA
                mvl.A = mvl.A + mvl.alpha_a * dLdA;
            end
            
        case 'LineSearch',
            opt.alg='LineSearch';
            opt.verbose=0;
            opt.maxits=1;
            
            % Batch learning on single current sample
            tau.u=ut; tau.a=d; tau.r=r(t); tau.s=s(t);
            if mvl.updateA
                mvl = mvl_batch_learn (mvl,tau,opt);
                loglike = mvl.loglike;
            else
                [mvl,loglike] = mvl_update_W (mvl,tau,opt);
            end
            
        otherwise
            disp('Unknown algorithm in mvl_online_learn.m');
    end
    
end

tau.u=u;
tau.a=a;
tau.r=r;
tau.s=s;

mvl.loglike=loglike;
mvl.pc=exp(loglike/T);

% figure
% plot(hmax);

