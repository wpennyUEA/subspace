clear all
close all

task{1} = rl_task_qlr (0,1);
%task{1} = rl_task_qlr (1,1);

params = mvl_default_params ();
params.D=2;                     % Input Dimension
params.F=1;                     % Initial Feature Dimension
params.rbf_centres='fixed';     % Fixed or Constructive RBF centres ?
%params.rbf_centres='constr';    % Fixed or Constructive RBF centres ?
%params.h_thresh=0.5;            % Add a new RBF unit if max(h) under this threshold 


% Train set size and reps per size
%T=[40,60,80,100];
T=[50,100,150,200];
%Reps=10;
Reps=5;

% takes 2.5 mins with Reps=5

% Which models to run
run.mvl_rbf=1;
run.mvl_online=1;
run.mvl_config=0;
run.mvl_offline=0;
run.mvl_pruning=0;

% Create Training and Test Sets
for i=1:length(T),
    for r=1:Reps,
        datasplit.Ntrain=T(i);
        datasplit.Ntest=50;
        [train,test] = rl_task_train_test (task{1},datasplit,params.D);
        sim(i,r).train=train;
        sim(i,r).test=test;
        sim(i,r).train.s=ones(1,datasplit.Ntrain);
        sim(i,r).test.s=ones(1,datasplit.Ntest);
    end
end

for i=1:length(T),
    for r=1:Reps,
        disp(sprintf('Train set size = %d, Rep = %d',T(i),r));
        net = run_simulation (sim(i,r),run,task,params);
        res(i,r).net = net;
        M = length(net);
        for m=1:M,
            train_pc{m}(i,r)=net{m}.train_pc;
            test_pc{m}(i,r)=net{m}.test_pc;
            names{m}=net{m}.name;
        end
    end
end

params.cols={'k-','b-','r-','g-'};
params.M=M;
params.T=T;
params.Reps=Reps;
params.names=names;
params.train_pc=train_pc;
params.test_pc=test_pc;

plot_train_test_likelihoods (params);

c=clock;
cstr=['-',num2str(c(4)),'-',num2str(c(5))];
save_str=['save results/expt1',cstr,' run res params'];
disp(save_str);
eval(save_str);

