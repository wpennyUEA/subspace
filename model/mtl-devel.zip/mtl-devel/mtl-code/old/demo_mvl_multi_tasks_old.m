
clear all
close all

task{1} = rl_task_qlr (0,1);
task{2} = rl_task_lr (0,1);
N=length(task);

% Define Block Structure of Experiment
Tb=50;  % trials per block
reps=3; % number of blocks of each task
sblock=kron(ones(1,reps),[1:N]); % Task index by block
s=kron(sblock,ones(1,Tb)); % Task index by trial
Nb=length(sblock);
T=Nb*Tb;
start=1;
for b=1:Nb,
    block(b).ind=[start:start+Tb-1];
    start=start+Tb;
end

% Generate cue sequence over whole experiment
S=task{1}.S;
K=task{1}.K;
C=S^2;
u1=ones(C,1)/C;
c=spm_multrnd(u1,T);  % categorical/configural representation of input
for t=1:T,
    n=s(t); % Task
    u(:,t)=task{n}.u(:,c(t)); % continuous/integer representation of input
end
D=size(u,1);

% Configural learning for first block of each task
for b=1:N,
    disp(sprintf('Block %d configural learning',b));
    config{b}.alpha = 0.3;
    ind = block(b).ind;
    config{b} = config_learn(config{b},task{b},c(ind));
end

% Assume A known
% init='W';
% mvl.A=[1 -1];
% mvl.m=[-4:1:4];
% P=size(mvl.m,2);
% mvl.beta=3*ones(P,1);
        
% Set A=I, m and beta, and estimate W^1 from block 1 (task 1) data
disp('Initialising MVL on task 1 data');
init='AI';
mvl=[];
mvl = mvl_init_config (mvl,1,config{1},task{1},init);
mvl.alpha_A =0.05;
mvl.alpha_W = 0.3;
mvl.lambda=1;

% Estimate W^2 from block 2 (task 2) data
disp('Initialising MVL on task 2 data');
init='W';
mvl = mvl_init_config (mvl,2,config{2},task{2},init);

% Update MVL on remaining data
for b=3:Nb,
    for i=1:Tb,
        
        t=block(b).ind(i);
        n=s(t); % task
        
        % Make decision
        [v(:,t),hh,xx,dvdA] = mvl_value (mvl,n,u(:,t));
        a(t) = rl_decide(v(:,t),mvl.lambda);
        d = a(t);
        
        % Get reward
        [vtrue,pr(t),r(t)] = rl_task_reward (task{n},u(:,t),d);
        rpe(t) = r(t) - v(d,t);
        
        % Update W and A parameters
        %mvl.task(n).W(d,:) = mvl.task(n).W(d,:) + mvl.alpha_W * rpe(t) * hh';
        mvl.A = mvl.A + mvl.alpha_A * rpe(t) *dvdA{d};
        
        vd(t) = v(d,t);
        A(t,:)=mvl.A(1,:);
    end
end
ind=[2*Tb+1:T];
disp(sprintf('Mean Reward = %1.2f',mean(r(ind))));
disp(sprintf('Mean Reward Probability = %1.2f',mean(pr(ind))));

disp('A:');
disp(mvl.A);

figure
subplot(3,2,1);
plot(v');
xlabel('Trial');
ylabel('Values');
grid on
for k=1:K,
    dec_str{k}=int2str(k);
end
legend(dec_str);

subplot(3,2,2);
plot(vd);
xlabel('Trial');
ylabel('Value of Chosen Option');
grid on

subplot(3,2,3);
plot(a,'.');
ylim([0.9 K+0.1]);
xlabel('Trial');
ylabel('Action');
grid on

subplot(3,2,4);
plot(r);
xlabel('Trial');
ylabel('Reward');
ylim([-0.1 1.1]);
grid on

subplot(3,2,5);
plot(rpe);
xlabel('Trial');
ylabel('RPE');
grid on

subplot(3,2,6);
plot(A);
xlabel('Trial');
ylabel('A');
grid on
