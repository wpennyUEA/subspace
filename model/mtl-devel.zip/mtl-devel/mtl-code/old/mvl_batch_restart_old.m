function [mvl] = mvl_batch_restart (mvl,tau,F)
% MVL batch learning algorithm
% FORMAT [mvl] = mvl_batch_restart (mvl,tau,F)
%
% mvl       data structure
%               .pc_thresh
% tau       memories
% F         number of features (default = same as i/p)
%
% mvl       updated with
%           .loglike
%           .pc
%           .Ltraj
%           .Atraj{f} evolution of fth row of A

opt.alg = 'LineSearch';
opt.verbose = 0;
opt.maxpost = mvl.maxpost;

[D,T] = size(tau.u);

if nargin < 3 | isempty(F)
    F=D;
end

% Initialise RBF centres and precisions
if ~isfield(mvl,'m') | ~isfield(mvl,'beta')
    mvl = mvl_rbf_centres_tile (F);
end

% Number of RBF bases (including constant)
P = length(mvl.beta)+1;

N=length(mvl.task);
for n=1:N,
    % Number of actions
    K(n) = size(mvl.task(n).W,1);
end

% Prior mean and precision over rows of A
if ~isfield(mvl,'m0')
    mvl.m0=zeros(F,D);
end
if ~isfield(mvl,'Lambda0')
    for f=1:F,
        mvl.Lambda0(:,:,f)=mvl.rho*eye(D);
    end
end

max_restarts=8;
Ainit=zeros(F,D,max_restarts);

solution_found=0;
for r=1:max_restarts,
    
    % Initialisation
    Arnd = 0.1*randn(F,D);
    if r==1, 
        Ainit(:,:,r) = Arnd; 
    else
        % Make initialisation orthogonal to previous one
        ip=Ainit(:,:,r-1)*Arnd';
        Ainit(:,:,r) = Arnd-ip*Arnd;
    end
    mvl.A=Ainit(:,:,r);
    
    for n=1:N,
        mvl.task(n).W=randn(K(n),P);
    end
    
    mvl = mvl_batch_learn (mvl,tau,opt);
    disp(sprintf('Initialisation %d:  ProbCorr = %1.2f',r,mvl.pc));
    
    if mvl.pc > mvl.pc_thresh
        solution_found=1;
        break
    else
        restart(r).mvl=mvl;
        pc(r)=mvl.pc;
    end
end

if solution_found
    ind=r;
    pcorr=mvl.pc;
else
    [tmp,ind]=max(pc);
    pcorr=pc(ind);
    mvl=restart(ind).mvl;
end

disp(sprintf('Returning Solution %d, pc=%1.2f',ind,pcorr));