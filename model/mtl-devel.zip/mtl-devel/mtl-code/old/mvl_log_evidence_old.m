function [model,reduced] = mvl_log_evidence_old (mvl,n,tau)
% Compute Log Evidence for MVL
% FORMAT [model,reduced] = mvl_log_evidence_old (mvl,n,tau)
%
% mvl       data struct
% n         task
% tau       memories
% 
% model     Quantitites for full model (F rows)
%           .logev,.loglike,.logprior
% reduced   Quantities for reduced models (F-1 rows)
%           Entry (f) is for row f
%           .logev,.loglike,.logprior

% Log Likelihood
LLa = mvl_sum_log_like (mvl,n,tau);

% Log Prior
[F,D] = size(mvl.A);
LPa = -0.5*F*D*log(mvl.rho+2*pi);
for f=1:F
    af = mvl.A(f,:);
    LPa = LPa - 0.5*mvl.rho*af*af';
end

% Log Joint
J = LLa + LPa;

iC = zeros(D,D,F);
for f=1:F,
    af = mvl.A(f,:);
    lp(f) = LPa + 0.5*mvl.rho*af*af';
    
    tmp_mvl=mvl; tmp_mvl.A(f,:)=zeros(1,D);
    loglike(f) = mvl_sum_log_like (tmp_mvl,n,tau);
    
    H = spm_diff ('mvl_like_Ak',mvl,n,tau,f,af(:),[5 5]);
    iC(:,:,f) =-full(H)+mvl.rho*eye(D);
    
    ldC(f)=spm_logdet(squeeze(iC(:,:,f)));
end

% Log evidence of Full Model under Factorised Laplace
Fa = J-0.5*sum(ldC)+0.5*F*D*log(2*pi);

% Log evidence of row-reduced models
for f=1:F,
    Fp(f) = loglike(f) + lp(f)-0.5*sum(ldC)+0.5*ldC(f)+0.5*(F-1)*D*log(2*pi);
end

model.loglike=LLa;
model.logprior=LPa;
model.logev=Fa;

reduced.loglike=loglike;
reduced.logprior=lp;
reduced.logev=Fp;