
clear all
close all

S=25;
N=1000;

a=randn(S,1);
d=2*rand(S,1)-1;
ad=abs(d);

x=d'*a

dist=exp(-d.^2);
pd=dist/sum(dist);
n=spm_multrnd(pd,N);

x_monte_carlo=sum(a(n))/N