
clear all
close all

disp('');
disp('Experiment 4:');
disp('Comparing multitask learning approaches ...');

params = mvl_default_params ();
params.pc_thresh = 0.70;
params.offline_init='RBF';

make_easy=0;
if make_easy
    params.D=2;                     % Input Dimension
    params.F=2;                     % Initial Feature Dimension
    params.h_thresh=0.5;            % Add a new RBF unit if max(h) under this threshold
end

% Train set size and reps per size
T=[40,60,80,100];
%T=[50,100,150,200];
%Reps=10;
Reps=20;

% Roughly 2 mins per rep @ T=40

task{1} = rl_task_qlr (0,1);
task{2} = rl_task_lr (0,1);
N=length(task);

% Create Training and Test Sets
for i=1:length(T),
    for r=1:Reps,
        
        % Define Block Structure of Experiment
        Tb=T(i);  % trials per block
        b=1; % number of blocks of each task
        sblock=kron(ones(1,b),[1:N]); % Task index by block
        strain=kron(sblock,ones(1,Tb)); % Task index by trial
        stest=strain;

        datasplit.Ntrain=length(strain);
        datasplit.Ntest=length(stest);
        [train,test] = rl_task_train_test (task{1},datasplit,params.D);
        sim(i,r).train=train;
        sim(i,r).test=test;
        sim(i,r).train.s=strain;
        sim(i,r).test.s=stest;
    end
end

keyboard

for i=1:length(T),
    for r=1:Reps,
        disp(sprintf('Train set size = %d, Rep = %d',T(i),r));
        net = run_multitask_simulation (sim(i,r),task,params);
        res(i,r).net = net;
        M = length(net);
        for m=1:M,
            train_pc{m}(i,r)=net{m}.train_pc;
            test_pc{m}(i,r)=net{m}.test_pc;
            names{m}=net{m}.name;
        end
    end
end

params.cols={'ko-','kx-','kd-','ks-'};
params.M=M;
params.T=T;
params.Reps=Reps;
params.names={'RBF-Online','MVL-Offline','MVL-Pruning','MVL-Online'};
params.train_pc=train_pc;
params.test_pc=test_pc;

plot_train_test_likelihoods (params);

c=clock;
cstr=['-',num2str(c(4)),'-',num2str(c(5))];
save_str=['save results/expt4',cstr,' res params'];
disp(save_str);
eval(save_str);


