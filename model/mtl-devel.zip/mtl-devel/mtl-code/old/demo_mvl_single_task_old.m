
clear all
close all

task = rl_task_qlr (0,1);

T=250;
s=ones(T,1);

% single task
n=1;

% Generate cue sequence over whole experiment
S=task.S;
K=task.K;
C=S^2;
u1=ones(C,1)/C;
c=spm_multrnd(u1,T);  % categorical/configural representation of input
for t=1:T,
    u(:,t)=task.u(:,c(t)); % continuous/integer representation of input
end
D=size(u,1);

% Assume A known
init='W';
mvl.A=[1 -1]+0.5*randn(1,2);
%mvl.A=[1 -1];
%mvl.A=0.1*randn(1,2);
mvl.m=[-4:1:4];
P=size(mvl.m,2);
mvl.beta=3*ones(P,1);
P=P+1;
[F,D]=size(mvl.A);

%mvl.alpha_A = 0.25;
mvl.alpha_A = 0.01;
mvl.alpha_W = 1;
%mvl.alpha_W = 0;
mvl.lambda=1;
mvl.task(1).W=randn(K,P);

% Update MVL 
h=zeros(P,T);
for t=1:T,
    % Make decision
    [v(:,t),pv(:,t),hh,xx,dvdA] = mvl_value (mvl,n,u(:,t));
    a(t) = rl_decide(v(:,t),mvl.lambda);
    d = a(t);
    
    % Get reward
    [vtrue(:,t),pr(t),r(t)] = rl_task_reward (task,u(:,t),d);
    rpe(t) = r(t) - pv(d,t);
    
     % Update W and A parameters
     [L,dLdA,dLdW,dLdv] = log_like_sample (mvl,n,u(:,t),a(t),r(t));
     mvl.A = mvl.A + mvl.alpha_A * dLdA/norm(dLdA);
     mvl.task(n).W = mvl.task(n).W + mvl.alpha_W*dLdW;
    
%     h(:,t) = hh;
%     if t==50
%         H=h(:,1:t)';
%         yy=vtrue(:,1:t)';  % This is cheating because we have access to true values
%         mvl.task(1).W=(pinv(H)*yy)';
%         W50=mvl.task(1).W;
%     end
    
    vd(t) = v(d,t);  % Unsigned value of chosen option
    vd_true(t) = vtrue(d,t); %  True quantity
    
    pvd(t) = pv(d,t); % normalised value of chosen option
     % pr(t) is true quantity
     
    A(t,:)=mvl.A(1,:);
end
ind=[51:T];
disp(sprintf('Mean Reward = %1.2f',mean(r(ind))));
disp(sprintf('Mean Reward Probability = %1.2f',mean(pr(ind))));


disp('A:');
disp(mvl.A);

figure
subplot(3,2,1);
plot(v');
xlabel('Trial');
ylabel('Values');
grid on
for k=1:K,
    dec_str{k}=int2str(k);
end
legend(dec_str);

subplot(3,2,2);
plot(vd);
xlabel('Trial');
ylabel('Value of Chosen Option');
grid on

subplot(3,2,3);
plot(a,'.');
ylim([0.9 K+0.1]);
xlabel('Trial');
ylabel('Action');
grid on

subplot(3,2,4);
plot(r);
xlabel('Trial');
ylabel('Reward');
ylim([-0.1 1.1]);
grid on

subplot(3,2,5);
plot(rpe);
xlabel('Trial');
ylabel('RPE');
grid on

subplot(3,2,6);
plot(A);
xlabel('Trial');
ylabel('A');
grid on

% ind=[T-100:T];
% figure
% for k=1:K,
%     subplot(K,1,k);
%     plot(vtrue(k,:),v(k,:),'x');
%     grid on
%     xlabel('True unnorm value');
%     ylabel('Est unnorm value');
% end

% for t=T-100:T
%     disp([v(:,t), vtrue(:,t)])
% end

% figure;
% plot(vd_true(ind),vd(ind),'x');
% xlabel('True unnormalised Value');
% ylabel('Estimated unormalised Value');
% grid on
% 
% figure;
% plot(pr(ind),pvd(ind),'x');
% xlabel('True Normalised Value');
% ylabel('Estimated Normalised Value');
% grid on

