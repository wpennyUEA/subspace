
clear all
close all

task{1} = rl_task_qlr (0,1);
%task{1} = rl_task_qlr (1,1);

mvl = mvl_default_params ();

reps.train=3;
reps.test=20;
[train,test] = rl_task_set_fixed (task{1},reps,mvl.D);
train.s=ones(1,train.N);
test.s=ones(1,test.N);

T=train.N;           % Number of trials
episodes=1;

mvl.F=1;
mvl.Cinit=floor(T/episodes);
mvl.C=floor(T/episodes);
mvl.gamma_rpe=0;

mvl = mvl_sequential (mvl,task,train);

mvl_rbf = mvl_test(mvl.rbf_solution,task,test);
test_like_RBF=mvl_rbf.pcexp;
disp(' ');
disp(sprintf('TestLike RBF = %1.2f',test_like_RBF));
disp(' ');

N=[12:12:240];
for i=1:length(N),
    n=N(i);
    ntest=test;
    ntest.c=ntest.c(1:n);
    ntest.u=ntest.u(:,1:n);
    ntest.s=ntest.s(1:n);
    ntest.n=n;
    mvl = mvl_test(mvl,task,ntest);
    test_like(i)=mvl.pcexp;
end

figure
plot(N,test_like);
grid on
xlabel('Ntest');
ylabel('Test Like');

