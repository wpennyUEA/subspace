clear all
close all

%task = rl_task_qlr (0,1);
%task = rl_task_qlr (1,1);
%task = rl_task_config (1);
task = rl_task_lr(0,1);

datasplit.Ntrain=50;
datasplit.Ntest=50;
[train,test] = rl_task_train_test (task,datasplit);

opt.verbose=0;
[mvl,config,mvl_prune] = mvl_train (task, train, opt);
mvl.A
opt.net='rbf';
rbf = mvl_train(task,train,opt);
lambda=10;

net(1).name='mvl-pruned';
net(2).name='mvl';
net(3).name='rbf';
net(4).name='config';

% ELL on training set
mvl_prune = mvl_test (mvl_prune,task,train,lambda);
mvl = mvl_test (mvl,task,train,lambda);
rbf = mvl_test (rbf,task,train,lambda);
config = config_test (config,task,train,lambda);

net(1).Ltrain=mvl_prune.Lexp;
net(2).Ltrain=mvl.Lexp;
net(3).Ltrain=rbf.Lexp;
net(4).Ltrain=config.Lexp;

% ELL on test set
mvl_prune = mvl_test (mvl_prune,task,test,lambda);
mvl = mvl_test (mvl,task,test,lambda);
rbf = mvl_test (rbf,task,test,lambda);
config = config_test (config,task,test,lambda);

net(1).Ltest=mvl_prune.Lexp;
net(2).Ltest=mvl.Lexp;
net(3).Ltest=rbf.Lexp;
net(4).Ltest=config.Lexp;

disp(' ');
for n=1:length(net),
    disp(sprintf('%s Train Likelihood = %1.2f, Test Likelihood = %1.2f',net(n).name,net(n).Ltrain,net(n).Ltest));
end

