
clear all
close all

%nvl_task = nvl_task_define ();
rl_task = rl_task_qlr (0,1);

T=100;

S=rl_task.S;
K=rl_task.K;
C=S^2;

u1=ones(C,1)/C;
c=spm_multrnd(u1,T);

config.alpha=0.3;
config.lambda=10;
config.verbose=1;

config = config_learn(config,rl_task,c);




