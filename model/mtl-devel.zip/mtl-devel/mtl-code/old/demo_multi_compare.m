
clear all
close all

disp('');
disp('Comparing multitask learning approaches ...');

params = mvl_default_params ();
params.pc_thresh = 0.70;
params.offline_init='RBF';

make_easy=0;
if make_easy
    params.D=2;                     % Input Dimension
    params.F=2;                     % Initial Feature Dimension
    params.h_thresh=0.5;            % Add a new RBF unit if max(h) under this threshold
end

task{1} = rl_task_qlr (0,1);
task{2} = rl_task_lr (0,1);
N=length(task);

% Define Block Structure of Experiment
Tb=40;  % trials per block
reps=1; % number of blocks of each task
sblock=kron(ones(1,reps),[1:N]); % Task index by block
strain=kron(sblock,ones(1,Tb)); % Task index by trial
T=length(strain);
stest=strain;

% Create Training and Test Set Inputs
datasplit.Ntrain=T;
datasplit.Ntest=length(stest);
[train,test] = rl_task_train_test (task{1},datasplit,params.D);
sim.train=train;
sim.test=test;
sim.train.s=strain;
sim.test.s=stest;

net = run_multitask_simulation (sim,task,params);

disp(' ');
disp('Training Scores:');
for i=1:length(net)
    disp(sprintf('%s: Train Likelihood = %1.2f',net{i}.name,net{i}.mvl.pc));
end

disp(' ');
disp('Testing Scores:');
for i=1:length(net)
    disp(sprintf('%s: Test Likelihood = %1.2f',net{i}.name,net{i}.mvl.pcexp));
end

