function [mvl] = mvl_sequential (mvl,rl_task,train)
% MVL Sequential Bayesian Learning
% FORMAT [mvl] = mvl_sequential (mvl,rl_task,train)
%
% mvl           data structure
%                   .Cinit      initial learning period
%                   .C          buffer capacity
%                   .gamma_rpe  RPE threshold
%                   .verbose (0/1) default is 0
% rl_task       task data structure
% train         training data structure
%                   .u   [D x T] vector of inputs
%                   .s   [1 x T] task vector
%
% mvl           data structure
%                   .loglike
% tau           data for training MVL-offline
%                   .u      inputs
%                   .a      actions
%                   .r      rewards
%                   .s      task indices

if isfield(mvl,'verbose'),verbose=mvl.verbose; else verbose=0; end
if isfield(mvl,'lambda'), lambda=mvl.lambda; else lambda=10; end
if isfield(mvl,'alg'), alg=mvl.alg; else alg='LineSearch'; end

u = train.u;
s = train.s;

N=length(rl_task);
for n=1:N,
    K(n)=rl_task{n}.K;
end

[D,T] = size(u);
F = mvl.F;

inittrain.c=train.c(:,1:mvl.Cinit);
inittrain.u=train.u(:,1:mvl.Cinit);
inittrain.s=train.s(:,1:mvl.Cinit);

[mvl,tau] = mvl_rbf_learn (mvl,rl_task,inittrain);
m=mvl.m(1:F,:);
mvl.m=m;

%[mvl,tau] = mvl_uniform_agent (mvl,rl_task,inittrain);

% Update MVL parameters
mvl = mvl_batch_restart (mvl,tau,F);

% Empty memory buffer
tau.u=[]; tau.a=[]; tau.r=[]; tau.s=[];

% Update prior mean and precision
mvl.m0=mvl.mp;
mvl.Lambda0=mvl.Lambdap;

mvl.postA(1).m=mvl.mp;
mvl.postA(1).Lambda=mvl.Lambdap;
mvl.postA(1).Asd=mvl.Asd;
Nupdates=1;

arpe=[];
loglike=0;
for t=mvl.Cinit+1:T,
    
    ut = u(:,t);
    st = s(t);
    
    [vt,pvt,h,xt] = mvl_value (mvl,st,ut);
    
    % Make decision
    a(t) = rl_decide(vt,lambda);
    
    % Get reward
    d = a(t);
    [vtrue,pr(t),r(t)] = rl_task_reward (rl_task{st},ut,d);
     
    % Value (expected reward prob) of chosen option
    pi_d=pvt(d);
    loglike = loglike + r(t)*log(pi_d+eps) + (1-r(t))*log(1-pi_d+eps);
    
    arpe(t) = abs(r(t)-pi_d);
    if arpe(t) > (mvl.gamma_rpe-eps)
        % Add trial data to memory buffer
        tau.u=[tau.u,ut];
        tau.a=[tau.a,a(t)];
        tau.r=[tau.r,r(t)];
        tau.s=[tau.s,st];
    end
    
    Ctau=length(tau.r);
    if Ctau > (mvl.C-1)
        
        verbose=1;
        if verbose
            pa=length(find(tau.a==1))/Ctau;
            disp(sprintf('Sequential Updating from %d samples, pa=%1.2f',Ctau,pa));
        end
        % Memory buffer is full so update MVL parameters
        %opt.verbose=0;
        %mvl = mvl_batch_learn (mvl,tau,opt);
        mvl = mvl_batch_restart (mvl,tau,F);
        
        % Empty memory buffer
        tau.u=[]; tau.a=[]; tau.r=[]; tau.s=[];

        % Update prior mean and precision
        mvl.m0=mvl.mp;
        mvl.Lambda0=mvl.Lambdap;
        
        Nupdates=Nupdates+1;
        mvl.postA(Nupdates).m=mvl.mp;
        mvl.postA(Nupdates).Lambda=mvl.Lambdap;
        mvl.postA(Nupdates).Asd=mvl.Asd;

    end
    
end

mvl.loglike=loglike;
mvl.pc=exp(loglike/(T-mvl.Cinit));
mvl.arpe=arpe;


