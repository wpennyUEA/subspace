function [mvl,config,mvl_prune] = mvl_train (task, train, opt)
% Train MVL network
% FORMAT [mvl,config,mvl_prune] = mvl_train (task, train, opt)
%
% task      see e.g. rl_task_qlr
% train     .c, .u are training inputs
% opt       optimisation parameters
%               .verbose (0/1) default is 0
%               .net 'mvl' (default) or 'rbf'
%
% mvl       data structure
% config    see config_learn.m
% mvl_prune pruned MVL model

if isfield(opt,'verbose'), verbose=opt.verbose; else verbose=0; end
if isfield(opt,'net'), net=opt.net; else net='mvl'; end

config.alpha=0.3;
config.lambda=10;
config.verbose=verbose;

[config,tau] = config_learn (config,task,train.c);

n = 1;
[D,T] = size(tau.u);
F=D;
        
switch net
    case 'mvl',
        mvl = mvl_batch_restart (n,tau,F);
        if nargout > 2
            mvl_prune = mvl_batch_prune (mvl,n,tau,verbose);
        end
        
    case 'rbf',
        opt.alg = 'LineSearch';
        opt.maxits = 32;
        opt.verbose = verbose;
        
        mvl = mvl_rbf_centres_tile (F);
        P = length(mvl.beta)+1;
        K = length(unique(tau.a));
        mvl.task(1).W=randn(K,P);
        mvl.A = eye(D);
        [mvl,Lsum] = mvl_update_W (mvl,n,tau,opt);
        mvl.loglike=Lsum;
        mvl.pc=exp(mvl.loglike/T);
        disp(sprintf('RBF network,  ProbCorr = %1.2f',mvl.pc));
        if nargout > 2
            mvl_prune=mvl;
        end
        
    otherwise
        disp('Error: Unknown network type in mvl_train.m');
        return
end