function [mvl,removed] = mvl_remove_row (mvl,n,tau,verbose) 
% Remove a row of MVL feature matrix using greedy search
% FORMAT [mvl,removed] = mvl_remove_row (mvl,n,tau,verbose) 
%
% mvl       data struct
% n         task
% tau       memories
% 

if nargin < 4 | isempty(verbose), verbose=0; end

[model,reduced] = mvl_log_evidence (mvl,n,tau);

% Log Bayes Factors
logbf=reduced.logev-model.logev;
[maxlogbf,ind]=max(logbf);
if maxlogbf > 3
    disp(sprintf('Removing row, LogBF=%1.2f',maxlogbf));
    mvl.A(ind,:)=[];
    removed=1;
else
    removed=0;
end

if verbose
    disp(' ');
    disp('Statistical tests for removing rows - reduced versus full:');
    disp(' ');
    disp('LogBF:');
    disp(logbf);
    disp('LogLF:');
    disp(reduced.loglike-model.loglike);
end