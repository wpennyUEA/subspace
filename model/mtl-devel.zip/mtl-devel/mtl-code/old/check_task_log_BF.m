
clear all
close all

load evidence_test

[log_BF,reduced,debug] = mvl_task_log_BF (mvl,n,tau);
log_BF