function [logBF] = mvl_log_BF (mvl,n,tau)
% Compute Log Bayes Factors for MVL
% FORMAT [logBF] = mvl_log_BF (mvl,n,tau)
%
% mvl       data struct
% n         task
% tau       memories
% 
% logBF     Entry (f) is for row f

if isfield(mvl,'rho'), rho=mvl.rho; else rho=0.1; end
if isfield(mvl,'eta'), eta=mvl.eta; else eta=0.1; end

% Log Likelihood
LLa = mvl_sum_log_like (mvl,n,tau);

% Log Priors
[logPA,logPW] = mvl_log_prior (mvl);

% Log Joint
J = LLa + logPW;

iC = zeros(D,D,F);
for f=1:F,
    tmp_mvl = mvl; tmp_mvl.A(f,:) = zeros(1,D);
    lp = mvl_log_prior (tmp_mvl);
    loglike = mvl_sum_log_like (tmp_mvl,n,tau); 
    Jred=loglike+lp;
    
    af = mvl.A(f,:);
    H = spm_diff ('mvl_like_Ak',mvl,n,tau,f,af(:),[5 5]);
    iC =-full(H)+rho*eye(D);
    ldC = spm_logdet(iC);
    
    logBF(f) = Jred-J+0.5*ldC-0.5*D*log(2*pi);
end

