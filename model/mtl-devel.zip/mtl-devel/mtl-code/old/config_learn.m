function [config,tau] = config_learn (config,rl_task,c)
% Configural Reinforcement Learning
% FORMAT [config,tau] = config_learn (config,rl_task,c)
%
% config        data structure
%               .alpha  learning rate
%               .lambda decision noise
%               .verbose (0/1) default is 0
% rl_task       task data structure
% c             [T x 1] vector of input categories/configurations
%
% config        .Qmat [C x K] matrix of Q-values
%               .Qmat(c,j) is value for cth category of input and output
%               decision j
%               .mr         mean reward
%               .mrp        mean reward probability
%               .pa         prob of each action
%               .loglike    log likelihood of rewards
%               .pc         prob correct (=exp(.loglike/T))
% tau           data for training value network
%               .u      inputs
%               .a      actions
%               .r      rewards

if isfield(config,'verbose')
    verbose=config.verbose
else
    verbose=0;
end
if isfield(config,'lambda')
    lambda=config.lambda;
else
    lambda=10;
end

S=rl_task.S;
C=S^2;
K=rl_task.K;

T=length(c);

Q=0.5*ones(C,K,T);
%Q=zeros(C,K,T);

loglike=0;
for n=1:T,
    
    if n>1
        Q(:,:,n) = Q(:,:,n-1);
    end
    
    % Make decision
    j = c(n);
    v(:,n) = Q(j,:,n);
    a(n) = rl_decide(v(:,n),lambda);
    
    % Get reward
    d = a(n);
    u(:,n) = rl_task.u(:,j);
    [vtrue,pr(n),r(n)] = rl_task_reward (rl_task,u(:,n),d);
     
    % Value (expected reward prob) of chosen option
    vdn=v(a(n),n);
    loglike = loglike + r(n)*log(vdn+eps) + (1-r(n))*log(1-vdn+eps);
    
    rpe(n) = r(n) - v(d,n);
    Q(j,d,n) = Q(j,d,n) + config.alpha*rpe(n);
    
    vd(n)=v(d,n);
    
end

tau.c=c;
tau.u=u;
tau.a=a;
tau.r=r;

mr=mean(r);
mrp=mean(pr);

Qmat = squeeze(Q(:,:,T));
config.Qmat = Qmat;
config.mr=mr;
config.mrp=mrp;
config.loglike=loglike;
config.pc=exp(loglike/T);

for k=1:K,
    pa(k)=length(find(a==k));
end
config.pa=pa/T;

if ~verbose
    return
end

disp(sprintf('Mean Reward = %1.2f',mr));
disp(sprintf('Mean Reward Probability = %1.2f',mrp));
disp(sprintf('Log Likelihood = %1.2f',loglike));

figure
for j=1:C,
    subplot(S,S,j);
    plot(squeeze(Q(j,1,:)),'r');
    hold on
    plot(squeeze(Q(j,2,:)),'b');
    xlabel('Trial');
    ylabel('Values');
    grid on
end

figure
subplot(2,2,1);
plot(vd);
xlabel('Trial');
ylabel('Value of Chosen Option');
grid on

subplot(2,2,2);
plot(a,'.');
ylim([0.9 K+0.1]);
xlabel('Trial');
ylabel('Action');
grid on

subplot(2,2,3);
plot(r);
xlabel('Trial');
ylabel('Reward');
ylim([-0.1 1.1]);
grid on

subplot(2,2,4);
plot(rpe);
xlabel('Trial');
ylabel('RPE');
grid on