function [mvl] = mvl_init_config (mvl,n,config,task,type)
% Initialise MVL using configural model
% FORMAT [mvl] = mvl_init_config (mvl,n,config,task,type)
%
% mvl       data structure
% n         task index
% config    data structure
% task      data structure
% type      'W'

K=task.K;
S=task.S;
C=S^2;
D=size(task.u,1);

switch type
    case 'W',
        
        
    case 'AI',
        % Assume A=I
        % Set m and beta
        mvl.A=eye(D);
        P=9; % choose P configs as RBF centres
        ind=randperm(C);
        mvl.m=task.u(:,ind(1:P));
        mvl.beta=1*ones(P,1);
        
    otherwise
        disp('Unknown initialisation method in mvl_init_config.m');
        return
end

% Now estimate W assuming A, m, and beta are all known
P=size(mvl.m,2);
mvl.task(n).W=randn(K,P);

% Get RBF activations
for i=1:C,
    ui=task.u(:,i);
    % CHANGED BY ADDING pv *************************
    [v,pv,h(:,i),x(:,i)] = mvl_value(mvl,n,ui);
end
H=h';
Wt_hat=pinv(H)*config.Qmat;
mvl.task(n).W=Wt_hat';