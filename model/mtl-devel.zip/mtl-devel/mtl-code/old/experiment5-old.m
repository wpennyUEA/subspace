clear all
close all

task{1} = rl_task_qlr (0,1);
%task{1} = rl_task_qlr (1,1);

params = mvl_default_params ();

T=100;           % Number of trials

% Create Training and Test Set Inputs
datasplit.Ntrain=T;
datasplit.Ntest=50;
[train,test] = rl_task_train_test (task{1},datasplit,params.D);
train.s=ones(1,datasplit.Ntrain);
test.s=ones(1,datasplit.Ntest);

mvl.alpha_w=params.alpha_w;
mvl.alpha_a=params.alpha_a;
mvl.h_thresh=params.h_thresh;
mvl.rbf_centres=params.rbf_centres;
mvl.alg=params.onlinealg;
mvl.rho=params.rho;
mvl.pc_thresh=0.7;
mvl.maxpost=params.maxpost;

Reps=10;
T=100;

episodes=2;

mvl.F=4;
mvl.Cinit=floor(T/episodes);
mvl.C=floor(T/episodes);
mvl.gamma_rpe=0;
mvl_init=mvl;

% Create Training and Test Sets
for i=1:length(T),
    for r=1:Reps,
        datasplit.Ntrain=T(i);
        datasplit.Ntest=50;
        [train,test] = rl_task_train_test (task{1},datasplit,params.D);
        sim(i,r).train=train;
        sim(i,r).test=test;
        sim(i,r).train.s=ones(1,datasplit.Ntrain);
        sim(i,r).test.s=ones(1,datasplit.Ntest);
    end
end

for i=1:length(T),
    for r=1:Reps,
        disp(sprintf('Train set size = %d, Rep = %d',T(i),r));
        mvl = mvl_sequential (mvl_init,task,sim(i,r).train);
        mvl = mvl_test(mvl,task,sim(i,r).test);
        res(i,r).mvl=mvl;
        train_pc(i,r)=mvl.pc;
        test_pc(i,r)=mvl.pcexp
    end
end

mean(test_pc)

c=clock;
cstr=['-',num2str(c(4)),'-',num2str(c(5))];
save_str=['save results/expt5',cstr,' sim res params'];
disp(save_str);
eval(save_str);
