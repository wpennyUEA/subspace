
clear all
close all

load evidence_test

model = mvl_log_evidence_old (mvl,n,tau)

Wterms=1;
model = mvl_log_evidence (mvl,n,tau,Wterms)