function [mvl] = mvl_unvec_params (mvl,theta)
% Convert A and W matrices into single vector
% FORMAT [mvl] = mvl_unvec_params (mvl,theta)

a = theta(1:mvl.D*mvl.F);
mvl.A = reshape(a,mvl.F,mvl.D);
theta(1:mvl.D*mvl.F) = [];
N = length(mvl.task);
for n=1:N,
    [K,P] = size(mvl.task(n).W);
    w = theta(1:K*P);
    mvl.task(n).W = reshape(w,K,P);
    theta(1:K*P)=[];
end