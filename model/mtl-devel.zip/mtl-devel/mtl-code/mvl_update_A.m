function [mvl,Lsum] = mvl_update_A (mvl,tau,opt)
% Update Feature Matrix 
% FORMAT [mvl,Lsum] = mvl_update_A (mvl,tau,opt)
%
% mvl       data structure
% tau       memories
% opt       optimisation settings
%               .alg    'FixedStepSize' or 'LineSearch' (default)
%               .verbose 0/1 (default 0)
%               .alpha_A learning rate for 'FixedStepSize'
%               .maxpost 0/1 (default 1) for MaxPost (not MaxLike) updates
%
% mvl       with updated .A field
% Lsum      new batch log likelihood

if isfield(opt,'alg') alg=opt.alg; else alg='LineSearch'; end
if isfield(opt,'alpha_A') alpha_A=opt.alpha_A; else alpha_A = 0.01; end
if isfield(opt,'verbose') verbose=opt.verbose; else verbose=0; end

[Ls,dLdA] = mvl_sum_log_like (mvl,tau);

% if trace(mvl.Lambda0) > 1e6
%     keyboard
% end

if mvl.maxpost
    %disp('Max Post Updates for A');
    Psi = mvl_prior_deriv (mvl);
    dLdA = dLdA + Psi;
end
dLdA = dLdA/norm(dLdA);

switch alg,
    case 'FixedStepSize',
        mvl.A = mvl.A + alpha_A * dLdA;
        Lsum = Ls;
        
    case 'LineSearch',
        E = Inf;
        alpha_max = 1;
        improved=0;
        jmax=4;
        for j=1:jmax,
            [alpha, E] = fminbnd(@(alpha) mvl_tune_alpha(alpha,mvl,tau,dLdA),0,alpha_max);
            alpha_max = alpha_max/2;
            if -E > Ls
                improved=1;
                break;
            end
        end
        if improved
            mvl.A = mvl.A + alpha*dLdA;
            Lsum = -E;
        else
            Lsum = Ls;
        end
        
end

% Above terms may include log prior - just return log like
Lsum = mvl_sum_log_like (mvl,tau);