clear all
close all

task{1} = rl_task_qlr (0,1);
%task{1} = rl_task_qlr (1,1);

mvl = mvl_default_params ();

mvl.maxpost=0;               % MaxLike not MaxPost learning
mvl.D=2;                     % Input Dimension
mvl.F=2;                     % Initial Feature Dimension
params.rbf_centres='fixed';    % Fixed or Constructive RBF centres ?
params.h_thresh=0.5;            % Add a new RBF unit if max(h) under this threshold 
 
% 13-tight-clusters
% mvl.p0=0.9;                    % New cluster threshold in jdm_learn.m
% mvl.s0=0.1;                    % Encoding precision in jdm_learn.m

% 13-loose-clusters
mvl.p0=0.9;                    % New cluster threshold in jdm_learn.m
mvl.s0=0.5;                    % Encoding precision in jdm_learn.m

% 8-loose-clusters
% mvl.p0=0.001;                    % New cluster threshold in jdm_learn.m
% mvl.s0=0.75;                    % Encoding precision in jdm_learn.m

%mvl.onlinealg='RMSN';

% Number of cycles through training and test examples
reps.train=4;
reps.test=10;
%reps.train=10;
%reps.test=10;

[train,test] = rl_task_set_fixed (task{1},reps,mvl.D);
train.s=ones(1,train.N);
test.s=ones(1,test.N);

mvl_rbf=mvl;
[mvl_rbf,tau_rbf] = mvl_rbf_learn (mvl,task,train);
    
jdm.s0 = mvl.s0;
jdm.p0 = mvl.p0;
jdm = jdm_learn (jdm,tau_rbf);
jdm = jdm_test(jdm,task,train);
jdm.L = jdm.Lexp;
jdm.pc = jdm.pcexp;
jdm = jdm_test(jdm,task,test);

N=length(tau_rbf.r);
tau_jdm = jdm_sample (jdm,N);

figure
plot_tau (tau_rbf);
figure
plot_tau (tau_jdm);

for m=1:jdm.M,
    disp(sprintf('State %d:',m));
    disp(jdm.prior(m));
    disp(jdm.state(m).m);
    disp(jdm.state(m).beta);
end

s=1;uu=[];
Ns=20;
u1=linspace(0,6,Ns);
u2=u1;
for i=1:Ns,
    for j=1:Ns,
        ut=[u1(i) u2(j)]';
        uu=[uu,ut];
        pv = jdm_value (jdm,s,ut);
        value(i,j)=pv(1);
    end
end

figure
imagesc(u1,u2,value);
colormap gray
colorbar
axis xy
title('p(r=1|a=1,u)');
xlabel('u_1');
ylabel('u_2');



