%
% MULTITASK LEARNING CODE
%
% [1] Penny et al. MultiTask Learning from Brief Episodes: Computational
% Challenges. TechRep, Summer 2020.
% 
% Requires "spm-stats" and "sml-devel" on your search path
%
% -------------------------------------------------------------------------
% DEFAULT PARAMETERS
%
% mvl_default_params.m          For all demos and experiments
%
% -------------------------------------------------------------------------
% DEMOS
%
% debug_mvl_single_task.m       Single Task Demo
% demo_jdm.m                    Demonstrate Joint Density Model (JDM) 
%
% -------------------------------------------------------------------------
% SIMULATION CODE CALLED BY DEMOS AND EXPERIMENTS
%
% run_simulation.m
%
% -------------------------------------------------------------------------
% GET OUTPUT OF VALUE NETWORK
% 
% mvl_value.m
%
% -------------------------------------------------------------------------
% LOG-LIKELIHOOD
%
% log_like_sample.m             Log-likelihood of single sample
% mvl_sum_log_like.m            Log-likelihood of batch (and dLdA)
% mvl_sum_log_like_dW.m         Log-likelihood of batch (and dLdW)
% mvl_like_Ak.m                 Log-likelihood of batch as kth row of A
% mvl_like_wp.m                 Log-likelihood of batch as pth col of W
% mvl_test.m                    Expected LogL on test set
% get_accuracy_measures.m       In adddition to the one in mvl_test.m
%
% -------------------------------------------------------------------------
% OFFLINE LEARNING
%
% mvl_batch_learn.m             Batch learning
% mvl_batch_restart.m           Batch learning with restarts
% mvl_batch_prune.m             Batch learning with Bayesian Pruning
%
% -------------------------------------------------------------------------
% BAYESIAN COMPUTATION
%
% mvl_log_evidence.m            Compute log evidence
% mvl_log_prior.m               Compute log prior
% mvl_prune_features.m          Bayesian pruning
%
% mvl_post_precision.m          Compute post precision of rows of A 
% mvl_prior_deriv.m             Derivative of log prior of A
%
% -------------------------------------------------------------------------
% ONLINE LEARNING AND DECISION MAKING
%
% mvl_online_learn.m            MTL-Online
% mvl_rbf_learn.m               RBF-Online
% mvl_uniform_agent.m           Agent sampling actions from uniform density
%
% -------------------------------------------------------------------------
% RADIAL BASIS FUNCTION MODULE
%
% mvl_rbf.m                     Get output of RBF module
% mvl_rbf_centres_tile.m        Construct fixed RBF centres and precisions
% mvl_rbf_init.m                K-means initialisation of centres
% mvl_rbf_init.mat              For debugging
% review_rbf_units.m            Check what's been learnt
%
% -------------------------------------------------------------------------
% LINE SEARCH AND STEEPEST ASCENT
% 
% mvl_update_A.m                Update feature parameters (subspace)
% mvl_update_W.m                Update task parameters
% mvl_tune_alpha.m              Computes NegLogLike(A) for given step size
% mvl_tune_alpha_W.m            Computes NegLogLike(W) for given step size
% orth_vectors.m                Orthogonalise two vectors
%
% -------------------------------------------------------------------------
% RMS-PROP AND GRADIENT ASCENT WITH MOMENTUM 
%
% rmsn_init.m                   RMS Prop initialisation
% rmsn_update.m                 RMS Prop update
% momentum_update.m             Momentum update
% mvl_vec_gradient.m            To vectorise and unvectorise matrices
% mvl_vec_params.m              " "    
% mvl_unvec_params.m            " "
%
% -------------------------------------------------------------------------
% PLOTTING 
%
% plot_tasks.m
% plot_tau_config.m
% plot_test_likelihoods.m
% plot_train_test_likelihoods.m
%


