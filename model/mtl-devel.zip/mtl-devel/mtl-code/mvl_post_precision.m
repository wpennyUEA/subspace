function [ldC,Lambda,Asd] = mvl_post_precision (mvl,tau)
% Compute posterior precision and log determinant thereof 
% FORMAT [ldC,Lambda,Asd] = mvl_post_precision (mvl,tau)
% 
% mvl       data structure
% tau       memory buffer
%
% ldC       log determinant of posterior precision
% Lambda    Lambda(:,:,f) is posterior precision of fth row of mvl.A
% Asd       [F x D] matrix of standard deviations for entries in A

[F,D] = size(mvl.A);
Lambda = zeros(D,D,F);

ldC = 0;
for f=1:F,
    af = mvl.A(f,:);
    H = spm_diff ('mvl_like_Ak',mvl,tau,f,af(:),[4 4]);
    iC = -full(H) + squeeze(mvl.Lambda0(:,:,f));
    ldC = ldC + spm_logdet(iC);
    if nargout > 1
        Lambda(:,:,f)=iC;
    end
    if nargout > 2
        C=inv(iC);
        sd=sqrt(diag(C));
        Asd(f,:)=sd(:)';
%         if ~isreal(Asd(f,:))
%             keyboard
%         end
    end
end
