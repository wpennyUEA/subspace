function [mvl] = mvl_rbf_centres_tile (F)
% Set RBF centres and precisions
% FORMAT [mvl] = mvl_rbf_centres_tile (F)
%
% F         Number of features
%
% mvl       data structure
%           .m              centres
%           .beta           precisions
%           .P              number of reg coeffs (including for constant)
%           .task(n).W      K x W reg coeff matrix

switch F,
%     case 1,
%         xmin = -4;
%         xmax = 10;
%         Nrbf = 9;
%         delta = (xmax-xmin)/(Nrbf-1);
%         mvl.m = [xmin:delta:xmax];
%         mvl.beta = (3/delta)*ones(Nrbf,1);
%         P = Nrbf+1;
        
        
    case 1,
        xmin = -10;
        xmax = 10;
        Nrbf = 11;
        delta = (xmax-xmin)/(Nrbf-1);
        mvl.m = [xmin:delta:xmax];
        mvl.beta = (3/delta)*ones(Nrbf,1);
        P = Nrbf+1;
        
    case 2,
        xmin = 1;
        xmax = 5;
        Nrbf = 9;
        rN = ceil(sqrt(Nrbf));
        delta = (xmax-xmin)/(rN-1);
        m = [xmin:delta:xmax];
        k=1;
        for i=1:rN,
            for j=1:rN,
                mvl.m(1,k) = m(i);
                mvl.m(2,k) = m(j);
                k=k+1;
            end
        end
        P = size(mvl.m,2)+1;
        mvl.beta = sqrt(3/delta)*ones(P-1,1);
        
    otherwise
        disp(sprintf('Error in mvl_rbf_centres_tile: RBF initialisation undefined for F=%d',F));
        return
end

mvl.P = P;
