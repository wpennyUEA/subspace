function [logPA,logPW] = mvl_log_prior (mvl)
% Log Priors for MVL
% FORMAT [logPA,logPW] = mvl_log_prior (mvl)
%
% mvl       data struct
% 
% logPA     Log Prior over A
% logPW(n)  Log Prior over mvl.task(n).W

% Log Prior over A
[F,D] = size(mvl.A);
logPA = -0.5*F*D*log(2*pi);
for f=1:F,
    Lambda0 = squeeze(mvl.Lambda0(:,:,f));
    et = mvl.A(f,:)-mvl.m0(f,:);
    logPA = logPA + spm_logdet(Lambda0);
    logPA = logPA - 0.5*et*Lambda0*et';
end

if nargout > 1
    N=length(mvl.task);
    for n=1:N,
        % Log Prior over W
        [K(n),P] = size(mvl.task(n).W);
        logPW(n) = -0.5*K(n)*P*log(mvl.eta+2*pi);
        for p=1:P
            wp = mvl.task(n).W(:,p);
            logPW(n) = logPW(n) - 0.5*mvl.eta*wp'*wp;
        end
    end
end

