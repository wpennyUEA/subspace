function [Lsum] = mvl_like_wp (mvl,n,tau,p,w)
% Return batch log likelihood as a function of "w"
% FORMAT [Lsum] = mvl_like_wp (mvl,n,tau,p,w)
%
% mvl       data structure
% n         task index
% tau       memory structure
% p         pth column
% w         task(n).W(:,p)=w
%
% Lsum      batch log likelihood over trials t for which s(t)==n

T=length(tau.a);
mvl.task(n).W(:,p)=w;

ind = find(tau.s==n);
NT = length(ind);

for i=1:NT,
    t=ind(i);
    
    u=tau.u(:,t);
    a=tau.a(t);
    r=tau.r(t);
    
    L(i) = log_like_sample (mvl,n,u,a,r);
end
Lsum=sum(L);
