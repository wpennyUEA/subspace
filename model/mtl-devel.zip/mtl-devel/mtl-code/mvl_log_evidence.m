function [model,Lambdap,Asd] = mvl_log_evidence (mvl,tau,Wterms)
% Compute Log Evidence for MVL
% FORMAT [model,Lambdap,Asd] = mvl_log_evidence (mvl,tau,Wterms)
%
% mvl       data struct
% tau       memories
% Wterms    include W terms, default=1
% 
% model     Comprising
%           .logev,.loglike,.logprior
% Lambdap   Posterior Precision over A
% Asd       Error bars on A

if nargin < 3 | isempty(Wterms), Wterms=1; end

% Log Likelihood
LLa = mvl_sum_log_like (mvl,tau);
model.loglike=LLa;

% Log Prior
if Wterms
    [logPA,logPW] = mvl_log_prior (mvl);
else
    logPA = mvl_log_prior (mvl);
end

% Log Joint
J = LLa + logPA;

[F,D] = size(mvl.A);
if nargout > 1
    [ldC,Lambdap,Asd] = mvl_post_precision (mvl,tau);
else
    ldC = mvl_post_precision (mvl,tau);
end

% Log evidence under Factorised Laplace
Fa = J-0.5*ldC+0.5*F*D*log(2*pi);
model.logprior = logPA;

if Wterms
    % Include contributions from task matrix
    N=length(mvl.task);
    for n=1:N,
        [K,P] = size(mvl.task(n).W);
        ldC = 0;
        for p=1:P,
            wp = mvl.task(n).W(:,p);
            H = spm_diff ('mvl_like_wp',mvl,n,tau,p,wp,[5 5]);
            iC = -full(H) + mvl.eta*eye(K);
            ldC = ldC + spm_logdet(iC);
        end
        Fa = Fa + logPW(n) -0.5*ldC+0.5*K*P*log(2*pi);
        model.logprior = model.logprior+logPW(n);
    end
end

model.logev=Fa;

