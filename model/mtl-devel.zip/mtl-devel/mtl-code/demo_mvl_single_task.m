
clear all
close all

task{1} = rl_task_qlr (0,1);
%task{1} = rl_task_qlr (1,1);

mvl = mvl_default_params ();

mvl.D=2;
mvl.F=2;
mvl.rbf_s0=0.4;

% Number of cycles through Training and Test Set Inputs
reps.train=5;
%reps.train=10;
reps.test=10;

[train,test] = rl_task_set_fixed (task{1},reps,mvl.D);
T=train.N;
sim.train=train;
sim.test=test;
sim.train.s=ones(1,train.N);
sim.test.s=ones(1,test.N);

run.mvl_rbf=1;
run.mvl_online=0;
run.jdm_online=0;
run.mvl_config=0;
run.mvl_offline=1;
run.mvl_pruning=0;

net = run_simulation (sim,run,task,mvl);

for i=1:length(net)
    if strcmp(net{i}.name,'MVL-Offline')
        figure
        plot(net{i}.mvl.Atraj{1});
        grid on
        xlabel('Iteration');
        ylabel('A(1,:)');
        title('MVL-Offline');
        
        figure
        plot(net{i}.mvl.Ltraj);
        grid on
        xlabel('Iteration');
        ylabel('Train Likelihood');
        title('MVL-Offline');
    end
end

for i=1:length(net)
    figure
    hinton(net{i}.mvl.A);
    title(net{i}.name);
end

disp(' ');
disp('Training Scores:');
for i=1:length(net)
    disp(sprintf('%s: Train Likelihood = %1.2f',net{i}.name,net{i}.mvl.pc));
end

disp(' ');
disp('Testing Scores:');
for i=1:length(net)
    disp(sprintf('%s: Test Likelihood = %1.2f',net{i}.name,net{i}.mvl.pcexp));
end


net{1}.mvl.m
net{1}.mvl.beta
