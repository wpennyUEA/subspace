function [mvl,tau] = mvl_rbf_updateW (mvl,rl_task,train)
% RBF Learning within MVL framework - updating W only
% FORMAT [mvl,tau] = mvl_rbf_updateW (mvl,rl_task,train)
%
% See mvl_rbf_learn.m for inputs and outputs. In addition this function
% needs:
%
% mvl           data structure
%                   .m
%                   .beta
%                   .W

if isfield(mvl,'verbose'),verbose=mvl.verbose; else verbose=0; end
if ~isfield(mvl,'rho'), mvl.rho=1; end
if ~isfield(mvl,'eta'), mvl.eta=1; end

u = train.u;
s = train.s;
  
[D,T]=size(u);
mvl.A=eye(D);

loglike=0;
for t=1:T,
    
    ut = u(:,t);
    st = s(t);
    [vt,pvt,h,xt] = mvl_value (mvl,st,ut);
    
    % Make decision
    a(t) = rl_decide(vt,mvl.train_lambda);

    % Get reward
    d = a(t);
    [vtrue,pr(t),r(t)] = rl_task_reward (rl_task{st},ut,d);
     
    % Value (expected reward prob) of chosen option
    pi_d=pvt(d);
    loglike = loglike + r(t)*log(pi_d+eps) + (1-r(t))*log(1-pi_d+eps);
    
    % Update task weights
    [L,dLdA,dLdW] = log_like_sample (mvl,st,ut,d,r(t));
    mvl.task(st).W = mvl.task(st).W + mvl.alpha_w * dLdW;
    
end

tau.u=u;
tau.a=a;
tau.r=r;
tau.s=s;
tau.c=train.c;

mvl.loglike=loglike;
mvl.pc=exp(loglike/T);



