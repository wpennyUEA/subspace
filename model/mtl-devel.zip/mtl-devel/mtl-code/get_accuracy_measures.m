function [acc,yhat] = get_accuracy_measures (mvl,task,n)
% Get accuracy measures
% FORMAT [acc,yhat] = get_accuracy_measures (mvl,task,n)
%
% mvl,task,n
% acc           .pcu        expected loglikelihood on uniform test set
%                           (one example of each input)                        
%               .mabserr    mean absolute error in predicted/actual reward
%                           probabilities
%               .eru10      expected reward on 10 replications of uniform
%                           test set
%
% yhat          predicted reward probability map from mvl model

if nargin < 3 | isempty(n), n=1; end

%lambda=10;
lambda=mvl.test_lambda;

C=size(task{n}.u,2);
for c=1:C,
    ut=task{n}.u(:,c);
    [vt,pvt] = mvl_value (mvl,n,ut);
    yhat(ut(1),ut(2))=pvt(1);
    
    a = rl_decide(vt,lambda);
    [v,pr] = rl_task_reward(task{n},ut,a);
    ell(c) = pr*log(pvt(a)+eps)+(1-pr)*log(1-pvt(a)+eps);
end

Lexp=sum(ell);
acc.pcu=exp(Lexp/C);
acc.mabserr=mean(mean(abs(task{n}.y-yhat)));

S=10;
for s=1:S,
    for c=1:C,
        ut=task{n}.u(:,c);
        [vt,pvt] = mvl_value (mvl,n,ut);
        a = rl_decide(vt,mvl.test_lambda);
        [v,pr,rt] = rl_task_reward(task{n},ut,a);
        r(s,c)=rt;
    end
end
acc.eru10=mean(mean(r));
