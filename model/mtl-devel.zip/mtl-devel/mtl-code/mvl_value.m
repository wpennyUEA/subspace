function [vt,pvt,h,x,dvdA,GT] = mvl_value (mvl,n,ut)
% Return values from Modular Value Learning network
% FORMAT [vt,pvt,h,x,dvdA,GT] = mvl_value (mvl,n,ut)
%
% mvl       Data Structure
%           .A      [F x D] Encoding Matrix
%           .m      [F x (P-1)] basis function means
%           .beta   [(P-1) x 1] basis function precisions
%           .task(n).W      [K x P] Task Mapping
% n         task index
% ut        [D x 1] current input
%
% vt        [K x 1] signed values of current input
% pvt       [K x 1] normalised values (between 0 and 1)
% h         [P x 1] RBF outputs
% x         [F x 1] Feature outputs
% dvdA{d}   Derivative dvtd_dA
% GT        GT(f,k) used for analytic Hessian (not working !)

x = mvl.A*ut;
%tic; h = mvl_rbf (mvl,x); toc
%tic; hv = mvl_rbf_vec (mvl,x); toc
%keyboard
h = mvl_rbf (mvl,x);
vt = mvl.task(n).W*h;
pvt = exp(vt);
pvt = pvt/sum(pvt);

if nargout < 2
    return
end

% Compute derivatives
[F,P] = size(mvl.m);
K = size(mvl.task(n).W,1);
for k=1:K,
    gt=zeros(F,1);
    for p=1:P,
        gt = gt + mvl.task(n).W(k,p)*h(p)*mvl.beta(p)*(mvl.m(:,p)-x);
    end
    dvdA{k}=gt*ut';
    GT(:,k)=gt;
end
