function [mvl,rmsn] = rmsn_update(mvl,rmsn,g)
% RMS Prop with Momentum
% FORMAT [mvl,rmsn] = rmsn_update(mvl,rmsn,g)
%
% mvl       data structure
%               .rmsn_alpha Learning rate 
%               .rmsn_delta Small number 
%               .rmsn_beta Momentum parameter
%               .rmsn_rho Accumulation parameter
% rmsn      accumulated quantities
%               .r  squared gradient
%               .v  accumulated gradient
% g         sample gradient

% This is not Nesterov momentum as gradient
% is evaluated at theta_{t-1} not theta_{t-1}+beta*rmsn.v

rho = mvl.rmsn_rho;
beta = mvl.rmsn_beta;
alpha = mvl.rmsn_alpha;
delta = mvl.rmsn_delta;

rmsn.r = rho*rmsn.r + (1-rho)*g.^2;

x1 = sqrt (delta+rmsn.r);
dv = alpha./x1;
rmsn.v = beta*rmsn.v + dv.*g;

theta = mvl_vec_params (mvl);
theta = theta + rmsn.v;
mvl = mvl_unvec_params (mvl,theta);


