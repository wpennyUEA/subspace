function [mvl,Lsum] = mvl_update_W (mvl,n,tau,opt)
% Update Task Matrix 
% FORMAT [mvl,Lsum] = mvl_update_W (mvl,n,tau,opt)
%
% mvl       data structure
% n         task index
% tau       memories
% opt       optimisation settings
%               .alg    'FixedStepSize' or 'LineSearch' (default)
%               .verbose 0/1 (default 0)
%               .alpha_W learning rate for 'FixedStepSize'
%
% mvl       with updated .W field
% Lsum      new batch log likelihood

if isfield(opt,'alg') alg=opt.alg; else alg='LineSearch'; end
if isfield(opt,'alpha_W') alpha_W=opt.alpha_W; else alpha_W = 0.01; end
if isfield(opt,'verbose') verbose=opt.verbose; else verbose=0; end

switch alg,
    case 'FixedStepSize',
        [Lsum,dLdW] = mvl_sum_log_like_dW (mvl,n,tau);
        mvl.task(n).W = mvl.task(n).W + alpha_W * dLdW;
        
    case 'LineSearch',
        [Ls,dLdW] = mvl_sum_log_like_dW (mvl,n,tau);
        E = Inf;
        alpha_max = 1;
        improved=0;
        jmax=4;
        for j=1:jmax,
            [alpha, E] = fminbnd(@(alpha) mvl_tune_alpha_W (alpha,mvl,n,tau,dLdW),0,alpha_max);
            alpha_max = alpha_max/2;
            if -E > Ls
                improved=1;
                break;
            end
        end
        if improved
            mvl.task(n).W = mvl.task(n).W + alpha*dLdW;
            Lsum = -E;
        else
            Lsum = Ls;
        end
        
end