
close all
clear all

task{1} = rl_task_qlr (0,1);
task{2} = rl_task_lr (0,1);

figure
for n=1:2,
    subplot(1,2,n);
    imagesc(task{n}.y);
    colormap gray
    set(gca,'XTick',[1:task{n}.S]);
    set(gca,'YTick',[1:task{n}.S]);
    axis xy
    axis square
    xlabel('u_1');
    ylabel('u_2');
end