function [Lsum] = mvl_like_Ak (mvl,tau,k,a)
% Return batch log likelihood as a function of "a"
% FORMAT [Lsum] = mvl_like_Ak (mvl,tau,k,a)
%
% mvl       data structure
% tau       memory structure
% k         kth row
% a         A(k,:)=a
%
% Lsum      batch log likelihood

[F,D]=size(mvl.A);
T=length(tau.a);
mvl.A(k,:)=a(:)';
for t=1:T,
    u=tau.u(:,t);
    a=tau.a(t);
    r=tau.r(t);
    s=tau.s(t);
    
    L(t) = log_like_sample (mvl,s,u,a,r);
end
Lsum=sum(L);
