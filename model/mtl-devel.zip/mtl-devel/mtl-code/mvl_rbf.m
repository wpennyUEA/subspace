function [h] = mvl_rbf (mvl,x)
% Get RBF output
% FORMAT [h] = mvl_rbf (mvl,x)
%
% mvl       Data Structure
%           .m      [F x (P-1)] basis function means
%           .beta   [(P-1) x 1] basis function precisions
% x         [F x 1] Feature vector
%
% h         RBF outputs

Fchk=size(x,1);
x=x(:);

[F,P]=size(mvl.m);
if ~(F==Fchk)
    disp('Error in mvl_rbf: inconsistent dimensions');
    return
end

P=P+1;
h=zeros(P,1);
for p=1:P-1,
    e = x-mvl.m(:,p);
    d = 0.5*mvl.beta(p)*e'*e;
    h(p) = exp(-d);
end
h(P)=1;

