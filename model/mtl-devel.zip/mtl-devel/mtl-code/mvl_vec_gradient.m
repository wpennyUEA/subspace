function [g] = mvl_vec_gradient (mvl,s,dLdA,dLdW)
% Convert dLdA and dLdW matrices into single gradient vector
% FORMAT [g] = mvl_vec_gradient (mvl,s,dLdA,dLdW)

g = dLdA(:);
gW = dLdW(:);
NW = length(gW);
N = length(mvl.task);
for n=1:N,
    if n==s,
        g = [g; dLdW(:)];
    else
        g = [g; zeros(NW,1)];
    end
end