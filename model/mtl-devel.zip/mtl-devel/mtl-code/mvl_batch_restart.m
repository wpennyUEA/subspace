function [mvl,restart] = mvl_batch_restart (mvl,tau,F)
% MVL restart algorithm
% FORMAT [mvl,restart] = mvl_batch_restart (mvl,tau,F)
%
% mvl       data structure
%               .pc_thresh
%               .chains (default=9)
%               .BreakSearch (default 1) 1 to break when train_pc > pc_thresh
%                   
% tau       memories
% F         number of features (default = same as i/p)
%
% mvl       best mvl model
% restart   restart(r).mvl
%
% When run in "BreakSearch" mode - the function breaks after criterion is
% met. Precisions and evidence of each restart are not computed.
%
% When not run in this mode the function runs all .chains restarts and
% computes post precision and evidence for each.

if isfield(mvl,'BreakSearch') BreakSearch=mvl.BreakSearch; else BreakSearch=1; end
%if isfield(mvl,'chains') chains=mvl.chains; else chains=9; end
if isfield(mvl,'chains') chains=mvl.chains; else chains=10; end

opt.alg = 'LineSearch';
opt.verbose = 0;
opt.maxpost = mvl.maxpost;

[D,T] = size(tau.u);

if nargin < 3 | isempty(F)
    F=D;
end

% Initialise RBF centres and precisions
if ~isfield(mvl,'m') | ~isfield(mvl,'beta')
    mvl = mvl_rbf_centres_tile (F);
end

% Number of RBF bases (including constant)
P = length(mvl.beta)+1;

N=length(mvl.task);
for n=1:N,
    % Number of actions
    K(n) = size(mvl.task(n).W,1);
end

% Prior mean and precision over rows of A
if ~isfield(mvl,'m0')
    mvl.m0=zeros(F,D);
end
if ~isfield(mvl,'Lambda0')
    for f=1:F,
        mvl.Lambda0(:,:,f)=mvl.rho*eye(D);
    end
end

for f=1:F,
    Lambda0 = squeeze(mvl.Lambda0(:,:,f));
    mvl.C0(:,:,f) = inv(Lambda0);
end

max_restarts=chains;
Ainit=zeros(F,D,max_restarts);

solution_found=0;
for r=1:max_restarts,
    
    % Initialisation
    for f=1:F,
        C0=mvl.C0(:,:,f);
        afrnd=spm_normrnd(zeros(D,1),C0,1);
        Arnd(f,:)=afrnd';
    end
    if r==1
        mvl.A=mvl.m0+Arnd;
        Aprev=Arnd;
    else
        for f=1:F,
            % Make initialisation orthogonal to previous one
            tmp = orth_vectors(Arnd(f,:)',Aprev(f,:)');
            Aorth(f,:) = tmp';
        end
        mvl.A = mvl.m0 + Aorth;
        Aprev = Aorth;
    end

    mvl = mvl_batch_learn (mvl,tau,opt);
    disp(sprintf('Initialisation %d:  ProbCorr = %1.2f',r,mvl.pc));
    
    restart(r).mvl=mvl;
    pc(r)=mvl.pc;

    if BreakSearch
        if mvl.pc > mvl.pc_thresh
            solution_found=1;
            break
        end
    else
        % Mean and Precision of Posterior over A
        restart(r).mvl.mp = mvl.A;
        Wterms=0;
        [model,Lambdap,Asd] = mvl_log_evidence (mvl,tau,Wterms);
        %[ldC,Lambdap,Asd] = mvl_post_precision (mvl,tau);
        restart(r).mvl.Lambdap=Lambdap;
        restart(r).mvl.Asd=Asd;
        restart(r).mvl.logev=model.logev;
    end
    
end

if solution_found
    ind=r;
    pcorr=mvl.pc;
else
    [tmp,ind]=max(pc);
    pcorr=pc(ind);
    mvl=restart(ind).mvl;
end

disp(sprintf('Returning Solution %d, pc=%1.2f',ind,pcorr));