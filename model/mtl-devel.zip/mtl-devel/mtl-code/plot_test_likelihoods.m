function [] = plot_test_likelihoods (params)
% Plot test likelihoods versus train set size
% FORMAT [] = plot_test_likelihoods (params)
%
% params        simulation parameters
% 

cols=params.cols;
T=params.T;
Reps=params.Reps;
names=params.names;
train_pc=params.train_pc;
test_pc=params.test_pc;
M=params.M;

ms=8;

figure;
for m=1:M,
    %mean_test_pc(m,:)=median(test_pc{m}');
    mean_test_pc(m,:)=mean(test_pc{m}');
    std_test_pc(m,:)=std(test_pc{m}');
    offset=round(m-M/2);
    errorbar(T+offset,mean_test_pc(m,:),std_test_pc(m,:)/sqrt(Reps),cols{m},'MarkerSize',ms);
    hold on
end
grid on
legend(names{1:M});
xlabel('Number of training trials');
ylabel('Test Likelihood');
xlim([min(T)-5, max(T)+5]);

