function [Lsum,dLdA,HA] = mvl_sum_log_like (mvl,tau)
% Return batch log likelihood 
% FORMAT [Lsum,dLdA,HA] = mvl_sum_log_like (mvl,tau)
%
% mvl       data structure
% tau       memory structure
%
% Lsum      batch log likelihood
% dLdA      gradient
% HA        [D x D x F] (Analytic) Hessian matrix for rows of A
%           - not working !

[F,D]=size(mvl.A);
dLdA=zeros(F,D);
HA=zeros(D,D,F);
T=length(tau.a);
A=mvl.A;
for t=1:T,
    u=tau.u(:,t);
    a=tau.a(t);
    r=tau.r(t);
    s=tau.s(t);
    
    L(t) = log_like_sample (mvl,s,u,a,r);
    
    if nargout > 2
        [L(t),dLtdA,tmp1,tmp2,Hs] = log_like_sample (mvl,s,u,a,r);
        dLdA = dLdA + dLtdA;
        HA = HA + Hs;
        
    elseif nargout > 1
        [L(t),dLtdA] = log_like_sample (mvl,s,u,a,r);
        dLdA = dLdA + dLtdA;
    end
end
Lsum=sum(L);
