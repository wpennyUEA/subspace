
clear all
close all

task{1} = rl_task_qlr (0,1);
%task{1} = rl_task_qlr (1,1);

mvl = mvl_default_params ();

make_easy=1;
if make_easy
    mvl.D=2;
    mvl.F=1;
    mvl.h_thresh=0.5;
end

% Number of cycles through Training and Test Set Inputs
reps.train=3;
reps.test=10;

[train,test] = rl_task_set_fixed (task{1},reps,mvl.D);
T=train.N;
train.s=ones(1,train.N);
test.s=ones(1,test.N);

% Initialise
learn_again=0;
if learn_again,
    mvl_rbf=mvl;
    [mvl_rbf,tau_rbf] = mvl_rbf_learn (mvl,task,train);
    mvl_rbf_init=mvl_rbf;
else
    load mvl_rbf_init
    mvl_rbf = mvl_rbf_init;
end

F=mvl.F;
m=mvl_rbf.m(1:F,:);
m=[-4:1:3];
mvl_rbf.m=m;
mvl_rbf.BreakSearch=1;
mvl_rbf.chains=18;
mvl_rbf.maxits=16;
mvl_rbf.tol=0.001;
[mvl_offline,restarts] = mvl_batch_restart (mvl_rbf,tau_rbf,mvl.F);
for r=1:length(restarts),
    pc(r)=restarts(r).mvl.pc;
end
figure; plot(pc,'x');

mvl_offline = mvl_test(mvl_offline,task,test);

test_like=mvl_offline.pcexp;
disp(sprintf('Test Like = %1.2f',test_like));

figure
plot(mvl_offline.Ltraj);
grid on
xlabel('Iteration');
ylabel('Train Likelihood');
title('MVL-Offline');

figure
plot(mvl_offline.Atraj{1});
grid on
xlabel('Iteration');
ylabel('A(1,:)');
title('MVL-Offline');

% figure
% plot_tau (tau_rbf);
% 
% mvl_rbf.m
