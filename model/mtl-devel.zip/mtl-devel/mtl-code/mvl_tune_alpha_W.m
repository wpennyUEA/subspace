function [E] = mvl_tune_alpha_W (alpha,mvl,n,tau,dLdW)
% Evaluate negative log likelihood (error) 
% FORMAT [E] = mvl_tune_alpha_W (alpha,mvl,n,tau,dLdW)
%
% alpha     Step size
% mvl       mvl data structure
% n         task index
% tau       memory buffer
% dLdW      Gradient
%
% E         Negative log likelihood (error)

mvl.task(n).W = mvl.task(n).W + alpha*dLdW;
Ls = mvl_sum_log_like_dW (mvl,n,tau);
E = -Ls;