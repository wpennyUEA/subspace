function [Lsum,dLdW] = mvl_sum_log_like_dW (mvl,n,tau)
% Return batch log likelihood 
% FORMAT [Lsum,dLdW] = mvl_sum_log_like_dW (mvl,n,tau)
%
% mvl       data structure
% n         task index
% tau       memory structure
%
% Lsum      batch log likelihood (over samples for which tau.s(t)==n)
% dLdW      gradient of Lsum wrt mvl.task(n).W

[F,D]=size(mvl.A);
dLdA=zeros(F,D);
T=length(tau.a);
[K,P] = size(mvl.task(n).W);
dLdW = zeros(K,P);

ind = find(tau.s==n);
NT=length(ind);

for i=1:NT,
    t=ind(i);
    
    u=tau.u(:,t);
    a=tau.a(t);
    r=tau.r(t);
    
    if nargout > 1
        [L(t),tmp,dLtdW] = log_like_sample (mvl,n,u,a,r);
        dLdW = dLdW + dLtdW;
    else
        L(i) = log_like_sample (mvl,n,u,a,r);
    end
end
Lsum=sum(L);
