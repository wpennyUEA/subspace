function [] = plot_tau (tau)
% Plot Data Epoch
% FORMAT [] = plot_tau (tau)

plot(tau.u(1,:),tau.u(2,:),'x');
ma=mean(tau.a);
mr=mean(tau.r);
title(sprintf('a=%1.2f, r=%1.2f',ma,mr));

uc=unique(tau.c);
Nu=length(uc);
for c=1:Nu,
    ind=find(tau.c==uc(c));
    ma(c)=mean(tau.a(ind));
    mr(c)=mean(tau.r(ind));
    disp(sprintf('%d pa=%1.2f, pr=%1.2f',uc(c),ma(c),mr(c)));
end

