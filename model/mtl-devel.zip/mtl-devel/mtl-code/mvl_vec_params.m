function [theta] = mvl_vec_params (mvl)
% Convert A and W matrices into single vector
% FORMAT [theta] = mvl_vec_params (mvl)

theta = mvl.A(:);
N = length(mvl.task);
for n=1:N,
    theta = [theta; mvl.task(n).W(:)];
end