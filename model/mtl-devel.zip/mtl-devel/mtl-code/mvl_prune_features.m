function [mvl,removed] = mvl_prune_features (mvl,tau,verbose)
% Prune feature mapping
% FORMAT [mvl,removed] = mvl_prune_features (mvl,tau,verbose)
%
% mvl       data struct
% tau       memories
% verbose   default=0
% 
% mvl       new MVL model
% removed   1 if row in A was removed, 0 otherwise

if nargin < 3 | isempty(verbose), verbose=0; end

logBF_threshold=log(10);
%logBF_threshold=log(20);

opt.alg = 'LineSearch';
opt.verbose = 0;
opt.W_first = 1;

Wterms = 0;
model = mvl_log_evidence (mvl,tau,Wterms);
    
[F,D] = size(mvl.A);
for f=1:F,
    tmp{f}=mvl;
    tmp{f}.A(f,:)=[];
    
    % Prune RBF centres
    tmp{f}.m(f,:)=[];
    
    % Update params of reduced model
    tmp{f} = mvl_batch_learn (tmp{f},tau,opt);
    
    tmp_model = mvl_log_evidence (tmp{f},tau,Wterms);

    reduced.logev(f) = tmp_model.logev;
    reduced.loglike(f) = tmp_model.loglike;
end

% Log Bayes Factors
logbf=reduced.logev-model.logev;
[maxlogbf,ind]=max(logbf);
if maxlogbf > logBF_threshold
    disp(sprintf('Removing row, LogBF=%1.2f',maxlogbf));
    mvl=tmp{ind};
    removed=1;
else
    removed=0;
end

if verbose
    disp(' ');
    disp('Statistical tests for removing rows - reduced versus full:');
    disp(' ');
    disp('LogBF:');
    disp(logbf);
    disp('LogLF:');
    disp(reduced.loglike-model.loglike);
end

