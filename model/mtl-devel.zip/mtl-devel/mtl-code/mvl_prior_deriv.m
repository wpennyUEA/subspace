function [Psi] = mvl_prior_deriv (mvl)
% Compute derivative of log prior
% FORMAT [Psi] = mvl_prior_deriv (mvl)
%
% mvl           data structure
%
% Psi           [F x D] matrix containing derivative of log prior wrt A

[F,D] = size(mvl.A);

Psi=zeros(F,D);
for f=1:F,
    af = mvl.A(f,:);
    Lambda0=squeeze(mvl.Lambda0(:,:,f));
    e=(mvl.A(f,:)-mvl.m0(f,:))';
    Psi(f,:) = -(Lambda0*e)';
end