function [rl_task] = rl_task_lr (sum_task, high_acc)
% Define Logistic Regression task
% FORMAT [rl_task] = rl_task_lr (sum_task, high_acc)
%
% sum_task      1/0 for sum/diff task
% high_acc      1/0 for high/low potential accuracy
%
% rl_task       .type   'qlr'
%               .w,     input weights
%               .b      bias weight
%               .u      u(:,k) where k is input category

if nargin < 2
    high_acc=1;
end
if nargin < 1
    sum_task=1;
end

% Parametric inputs
S=5;
c=1;
for i=1:S,
    for j=1:S,
        u(:,c)=[i;j];
        c=c+1;
    end
end

disp('Logistic Regression Task:');
if sum_task
    disp('Sum Mapping');
    w=[1 1];
    b=-5.5;
else
    disp('Diff Mapping');
    w=[1 -1];
    b=0.5;
end

if high_acc
    disp('High Accuracy');
    lambda=3.5;
else
    disp('Low Accuracy');
    lambda=1.3;
end

maxlike=0;
for k=1:S^2,
    x = lambda*(w*u(:,k)+b);
    i=u(1,k);
    j=u(2,k);
    y(i,j) = mci_sigmoid(x);
    y_pattern(k) = y(i,j);
    maxlike=maxlike+max(y(i,j),1-y(i,j));
end

mean_prob=mean(mean(y));
corr_prob=maxlike/S^2;

rl_task.type='lr';
rl_task.w=w;
rl_task.b=b;
rl_task.lambda=lambda;
rl_task.S=S;
rl_task.K=2;
rl_task.u=u;
rl_task.y=y;

verbose=1;
if verbose
    figure
    imagesc(y);
    colormap gray
    colorbar
    title(sprintf('<y>=%1.2f, MaxCorr=%1.2f',mean_prob,corr_prob));
    set(gca,'XTick',[1:S]);
    set(gca,'YTick',[1:S]);
    axis xy
end

