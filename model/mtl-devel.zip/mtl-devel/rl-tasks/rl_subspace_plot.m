
close all
clear all

verbose = 1;
taskname={'Sub1','Sub2','Add1','Add2'};
no_details=1;
figure
for i=1:4,
    subplot(2,2,i);
    rl_task{i} = rl_subspace_task (taskname{i},verbose);
    if no_details
        title(taskname{i});
    end
    xlabel('u_2');
    ylabel('u_1');
    r=rl_task{i}.y;
    max_pcorr(i)=mean(mean(max(r,1-r)));
    disp(sprintf('Task %s Max Prob Corr = %1.2f',taskname{i},max_pcorr(i)));
    %xlabel('u_1');
    %ylabel('u_2');
end