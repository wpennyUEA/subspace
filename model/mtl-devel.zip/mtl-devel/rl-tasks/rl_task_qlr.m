function [rl_task] = rl_task_qlr (sum_task, high_acc, verbose)
% Define Quadratic Logistic Regression task
% FORMAT [rl_task] = rl_task_qlr (sum_task, high_acc, verbose)
%
% sum_task      1/0 for sum/diff task
% high_acc      1/0 for high/low potential accuracy
%
% rl_task       .type   'qlr'
%               .mu, .W, .w0 defines mapping from u to v, p(r)
%               .u      u(:,k) where k is input category

if nargin < 2
    high_acc=1;
end
if nargin < 1
    sum_task=1;
end

% Parametric inputs
S=5;
k=1;
for i=1:S,
    for j=1:S,
        u(:,k)=[i;j];
        k=k+1;
    end
end

disp('Quadratic Logistic Regression Task:');
if sum_task
    disp('Sum Mapping');
    wd=-0.7;
else
    disp('Diff Mapping');
    wd=0.7;
end

if high_acc
    disp('High Accuracy');
    W=1*[-0.71 wd; wd -0.71]*2.4;
    w0=4;
else
    disp('Low Accuracy');
    W=1*[-0.71 wd; wd -0.71];
    w0=2;
end

mu=[3,3]';

maxlike=0;
for k=1:S^2,
    x = u(:,k) - mu;
    v1(k) = x' * W * x + w0;
    v2(k) = -v1(k);
    i=u(1,k);
    j=u(2,k);
    y(i,j) = mci_sigmoid(v1(k));
    y_pattern(k) = y(i,j);
    maxlike=maxlike+max(y(i,j),1-y(i,j));
end

mean_prob=mean(mean(y));
corr_prob=maxlike/S^2;

rl_task.type='qlr';
rl_task.mu=mu;
rl_task.W=W;
rl_task.w0=w0;
rl_task.S=S;
rl_task.K=2;
rl_task.u=u;
rl_task.y=y;

if verbose
    imagesc(y);
    colormap gray
    colorbar
    title(sprintf('<y>=%1.2f, MaxCorr=%1.2f',mean_prob,corr_prob));
    set(gca,'XTick',[1:S]);
    set(gca,'YTick',[1:S]);
    axis xy
end

