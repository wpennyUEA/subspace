
clear all
close all

nvl_task = rl_task_nvl ();

n=1;
for i=1:nvl_task.S,
    for j=1:nvl_task.S,
        u(:,n)=[i,j]';
        vn = rl_task_reward (nvl_task,u(:,n));
        for k=1:nvl_task.K,
            nvl_task.value_map{k}(i,j)=vn(k);
        end
        n=n+1;
    end
end

figure
rK=ceil(sqrt(nvl_task.K));
for k=1:nvl_task.K,
    subplot(rK,rK,k);
    imagesc(nvl_task.value_map{k});
    title(sprintf('Response %d',k));
    colorbar
    axis xy
end
