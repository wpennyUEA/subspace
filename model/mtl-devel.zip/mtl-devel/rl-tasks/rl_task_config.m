function [rl_task] = rl_task_config (high_acc,K)
% Define Configural RL task
% FORMAT [rl_task] = rl_task_config (high_acc,K)
%
% high_acc      1/0 for high/low potential accuracy
% K             number of actions (default K=2)
%
% rl_task       .type   'config'
%               .Q(c,k) prob reward given i/p category c, action k
%               .u      u(:,c) where c is input category

if nargin < 1, high_acc=1; end
if nargin < 2, K=2; end

% Parametric inputs
S=5;
c=1;
for i=1:S,
    for j=1:S,
        u(:,c)=[i;j];
        c=c+1;
    end
end

disp('Configural RL Task:');

if high_acc
    disp('High Accuracy');
    pr=0.95;
else
    disp('Low Accuracy');
    pr=0.83;
end

% Define optimal actions - uniform distribution
%pu=ones(K,1)/K;
%a = spm_multrnd(pu,S^2);

% Define optimal actions - enforce (almost) same number of each
C=S^2;
N=floor(C/K)*ones(K,1);
N(1)=N(1)+C-sum(N);
aa = [];
for k=1:K,
    aa=[aa;k*ones(N(k),1)];
end
ind=randperm(C);
a=aa(ind);

% Define true Q-values
for c=1:S^2,
    i=u(1,c);
    j=u(2,c);
    d=a(c);
    Q(d,c) = pr;
    for k=1:K,
        if ~(k==d)
            Q(k,c)=(1-pr)/(K-1);
        end
    end
    y(i,j) = Q(1,c);
    y_pattern(c) = y(i,j);
end

mean_prob=mean(mean(y));
corr_prob=pr;

rl_task.type='config';
rl_task.Q=Q;
rl_task.S=S;
rl_task.K=2;
rl_task.u=u;

verbose=1;
if verbose
    figure
    imagesc(y);
    colormap gray
    colorbar
    title(sprintf('<y>=%1.2f, MaxCorr=%1.2f',mean_prob,corr_prob));
    set(gca,'XTick',[1:S]);
    set(gca,'YTick',[1:S]);
    axis xy
end

