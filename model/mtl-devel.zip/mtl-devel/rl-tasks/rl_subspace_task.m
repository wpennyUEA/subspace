function [rl_task] = rl_subspace_task (taskname,verbose)
% Define subspace task
% FORMAT [rl_task] = rl_subspace_task (taskname,verbose)
%
% taskname      'Sub1','Sub2','Add1','Add2'
%
% rl_task       .type   'qlr' or 'linear'
%               .mu, .W, .w0 defines mapping from u to v, p(r)
%               .u      u(:,k) where k is input category
%
% This script is derived from generate_maps.m that produced the
% maps used in the Subspace Experiment

switch taskname,
    case 'Sub1',    
        rl_task = rl_task_qlr (0,1,verbose);
        
    case 'Add1',
        rl_task = rl_task_qlr (1,1,verbose);
        
    otherwise
        rl_task = rl_task_linear(taskname,verbose);
end












