function [rl_task] = rl_task_linear (task_type,verbose)
% Define Logistic Regression task (Sub2,Add2)
% FORMAT [rl_task] = rl_task_linear (task_type,verbose)
%
% task_type     'Sub2','Add2'
%               .mu, .w1, .w2 defines mapping from u to v, p(r)
%               .u      u(:,k) where k is input category

switch task_type,
    case 'Sub2',
        rl_task.w1=5.5;
        rl_task.w2=-5.5;
        rl_task.mu=[1.1 1]';
        
    case 'Add2',
        rl_task.w1=5.5;
        rl_task.w2=5.5;
        rl_task.mu=[1.1 5]';
end
rl_task.type='linear';

% Parametric inputs
S=5;
k=1;
for i=1:S,
    for j=1:S,
        u(:,k)=[i;j];
        k=k+1;
    end
end

maxlike=0;
for k=1:S^2,
    pr = rl_task_reward (rl_task,u(:,k));
    i=u(1,k);
    j=u(2,k);
    %y(i,j) = mci_sigmoid(v(1));
    y(i,j) = pr(1);
    y_pattern(k) = y(i,j);
    maxlike=maxlike+max(y(i,j),1-y(i,j));
end

mean_prob=mean(mean(y));
corr_prob=maxlike/S^2;

rl_task.S=S;
rl_task.K=2;
rl_task.u=u;
rl_task.y=y;

if verbose
    imagesc(y);
    colormap gray
    colorbar
    title(sprintf('<y>=%1.2f, MaxCorr=%1.2f',mean_prob,corr_prob));
    set(gca,'XTick',[1:S]);
    set(gca,'YTick',[1:S]);
    axis xy
end



