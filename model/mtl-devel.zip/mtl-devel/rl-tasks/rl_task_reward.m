function [v,pr,r] = rl_task_reward (rl_task,u,a)
% Return values, reward probability and reward for an NVL task
% FORMAT [v,pr,r] = rl_task_reward (rl_task,u,a)
%
% rl_task       data structure
% u             [D x 1] input vector
% a             decision
%
% v             (signed) values as defined by task (i.e. true ones)
% pr            probability of reward (0 to 1)
% r             binary reward (0/1)

% Ignore all but first two inputs
u=u(1:2);

switch rl_task.type,
    
    case 'nvl',
        x=rl_task.A*u;
        e=(x-rl_task.xs).^2;
        p=exp(-e);
        p=p/sum(p);
        v=rl_task.vs'*p;
        
        % NOTE LAMBDA FACTOR HERE ***********************
        lambda=10;
        rp=mci_softmax(v,lambda);
        
    case 'qlr',
        x = u - rl_task.mu;
        act = x' * rl_task.W * x + rl_task.w0;
        v(1) = act;
        v(2) = -v(1);
        v = v(:);
        rp = mci_softmax(v);
    
    case 'lr',
        x = rl_task.lambda*(rl_task.w*u+rl_task.b);
        v(1) = mci_sigmoid(x);
        v(2) = 1-v(1);
        v = v(:);
        rp = v;
        
    case 'linear',
        d = u - rl_task.mu;
        x = rl_task.w1*d(1)+rl_task.w2*d(2);
        v(1) = mci_sigmoid(x);
        v(2) = 1-v(1);
        v = v(:);
        rp = v;
        
        
    case 'config',
        mismatch = sum(abs(rl_task.u-u(:)));
        c = find(mismatch==0);
        v = rl_task.Q(:,c);
        rp = v;
        
    otherwise
        disp('Unknown RL task type in rl_task_reward.m');
        return
end

if nargin > 2
    pr = rp(a);
    rr = spm_multrnd([1-pr pr],1);
    r = rr-1;
else
    r=[];
    pr=[];
end

