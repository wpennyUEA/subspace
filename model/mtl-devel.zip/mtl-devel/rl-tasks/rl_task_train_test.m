function [train,test] = rl_task_train_test (task,datasplit,D)
% Generate training and testing data sets for RL tasks
% FORMAT [train,test] = rl_task_train_test (task,datasplit,D)
%
% task          see e.g. rl_task_qlr.m
% datasplit     .train_cues, .test_cues, Ntrain, Ntest
% D             dimension of input
%
% train         .c  input categories
%               .u  input vectors
% test          .c, .u

if isfield(datasplit,'train_cues')
    train_cues=datasplit.train_cues;
else
    train_cues=[1,3,5,8,9,12,13,16,17,20,21,24,25];
end
if isfield(datasplit,'test_cues')
    test_cues=datasplit.test_cues;
else
    test_cues=[2,4,6,7,10,11,14,15,18,19,22,23];
end

if isfield(datasplit,'Ntrain'), Ntrain=datasplit.Ntrain; else Ntrain=100; end
if isfield(datasplit,'Ntest'), Ntest=datasplit.Ntest; else Ntest=100; end

% Create training set
C=length(unique(train_cues));
u1=ones(C,1)/C;
c=spm_multrnd(u1,Ntrain);  % categorical/configural representation of input
for t=1:Ntrain,
    train.c(t)=train_cues(c(t));    
    train.u(:,t)=task.u(:,train.c(t)); % vector representation of input
end

% Create testing set
C=length(unique(test_cues));
u1=ones(C,1)/C;
c=spm_multrnd(u1,Ntest);  % categorical/configural representation of input
for t=1:Ntest,
    test.c(t)=test_cues(c(t));    
    test.u(:,t)=task.u(:,test.c(t)); % vector representation of input
end

if D > 2
    % Add spurious inputs
    u_noise=rand(D-2,Ntrain)*task.S;
    train.u=[train.u;u_noise];
    
    u_noise=rand(D-2,Ntest)*task.S;
    test.u=[test.u;u_noise];
end