function [nvl_task] = rl_task_nvl ()
% Define NVL task
% FORMAT [nvl_task] = rl_task_nvl ()
%
% .S        Number of values of each cue variable
% .K        Number of Actions
% .A        Feature matrix
% .xs       Feature Samples
% .vs       Value Samples

nvl_task.type='nvl';
nvl_task.S=5;
nvl_task.K=3;
nvl_task.A=[1,-1];
%nvl_task.xs=[-2,0,2]'; % equipartition into K 
%nvl_task.vs=eye(nvl_task.K);


nvl_task.xs=[-4:1:4]'; 
nvl_task.vs=[[1 0 0]'*ones(1,3),[0 1 0]'*ones(1,3),[0 0 1]'*ones(1,3)]';