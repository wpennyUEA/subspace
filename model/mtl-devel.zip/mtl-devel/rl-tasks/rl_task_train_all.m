function [train] = rl_task_train_all (task,Ntrain,D)
% Generate training data set for RL task
% FORMAT [train] = rl_task_train_all (task,Ntrain,D)
%
% task          see e.g. rl_task_qlr.m
% Ntrain        number of exemplars
% D             dimension of input
%
% train         .c  input categories
%               .u  input vectors

train_cues=[1:25];

% Create training set
C=length(unique(train_cues));
u1=ones(C,1)/C;
c=spm_multrnd(u1,Ntrain);  % categorical/configural representation of input
for t=1:Ntrain,
    train.c(t)=train_cues(c(t));    
    train.u(:,t)=task.u(:,train.c(t)); % vector representation of input
end

if D > 2
    % Add spurious inputs
    u_noise=rand(D-2,Ntrain)*task.S;
    train.u=[train.u;u_noise];
end