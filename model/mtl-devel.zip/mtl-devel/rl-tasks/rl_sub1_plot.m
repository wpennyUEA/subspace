
close all
clear all

taskname={'Sub1','Sub2','Add1','Add2'};
i=4;
figure
rl_task{i} = rl_subspace_task (taskname{i});
xlabel('u_1');
ylabel('u_2');
title(taskname{i});