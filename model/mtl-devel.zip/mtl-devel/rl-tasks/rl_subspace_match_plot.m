
close all
clear all

taskname={'Sub1','Sub2','Add1','Add2'};
no_details=1;
figure
%ind=[1,2,3,2];
ind=[3,4,1,4];
for j=1:4,
    i=ind(j);
    subplot(2,2,j);
    rl_task{i} = rl_subspace_task (taskname{i});
    if no_details
        title(taskname{i});
    end
    r=rl_task{i}.y;
    max_pcorr(i)=mean(mean(max(r,1-r)));
    disp(sprintf('Task %s Max Prob Corr = %1.2f',taskname{i},max_pcorr(i)));
    %xlabel('u_1');
    %ylabel('u_2');
end