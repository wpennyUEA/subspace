clear all
close all

task = rl_task_qlr (0,1);
%task = rl_task_qlr (1,1);

[train,test] = rl_task_train_test (task,[])