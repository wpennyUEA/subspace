function [train,test] = rl_task_set_fixed (task,reps,D)
% Generate training and testing data sets for RL tasks
% FORMAT [train,test] = rl_task_set_fixed (task,reps,D)
%
% task          see e.g. rl_task_qlr.m
% reps          number of repetitions of each cue
%                .train, .test
% D             dimension of input
%
% train         .c  input categories
%               .u  input vectors
% test          .c, .u

train_cues=[1,3,5,8,9,12,13,16,17,20,21,24,25];
test_cues=[2,4,6,7,10,11,14,15,18,19,22,23];

train.c=kron(ones(1,reps.train),train_cues);
train.N=length(train.c);
for t=1:train.N,
    train.u(:,t)=task.u(:,train.c(t)); % vector representation of input
end

test.c=kron(ones(1,reps.test),test_cues);
test.N=length(test.c);
for t=1:test.N,
    test.u(:,t)=task.u(:,test.c(t)); % vector representation of input
end

if D > 2
    % Add spurious inputs
    u_noise=rand(D-2,train.N)*task.S;
    train.u=[train.u;u_noise];
    
    u_noise=rand(D-2,test.N)*task.S;
    test.u=[test.u;u_noise];
end