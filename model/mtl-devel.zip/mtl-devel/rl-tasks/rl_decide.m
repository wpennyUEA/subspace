function [a,pa] = rl_decide (v,lambda)
% Make decision in RL model
% FORMAT [a,pa] = rl_decide (v,lambda)
%
% v         [K x 1] value vector
% lambda    Inverse decision variability

pa = mci_softmax(lambda*v);
a = spm_multrnd(pa,1);