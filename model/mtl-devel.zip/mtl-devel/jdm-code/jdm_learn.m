function [jdm] = jdm_learn (jdm,tau,diag)
% Online learning of JDM 
% FORMAT [jdm] = jdm_learn (jdm,tau,diag)
%
% jdm       data structure
%           .s0   initial standard deviation of input component
%           .p0   new cluster threshold (percentile of Chi^2 density)
% tau       memory buffer
% diag      1 for diagonal covariances (default = 0)
%
% mix       Mixture model data structure
%

if nargin < 3 | isempty(diag), diag=0; end

[D,N] = size(tau.u);
jdm.D = D;
jdm.K = length(unique(tau.a));
jdm.R = length(unique(tau.r));

for n=1:N,
    y(n).u = tau.u(:,n);
    y(n).a = tau.a(n);
    y(n).r = tau.r(n)+1;
end
jdm = jdm_init (jdm,y(1));

if diag
    for n=2:N,
        jdm = jdm_update_diag (jdm,y(n));
    end
else
    for n=2:N,
        jdm = jdm_update (jdm,y(n));
    end
end

for m=1:jdm.M,
    Ntot = sum(sum(jdm.state(m).b));
    jdm.state(m).beta = jdm.state(m).b/Ntot;
end

% jdm.loglike=loglike;
% jdm.pc=exp(loglike/N);