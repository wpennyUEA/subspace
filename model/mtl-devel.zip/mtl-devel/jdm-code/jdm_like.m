function [p,pc] = jdm_like (jdm,u,a,r)
% Compute probability of data under JDM
% FORMAT [p,pc] = jdm_like (jdm,u,a,r)
% 
% jdm       data structure
% u         input stimulus
% a         action
% r         reward
%      
% p          probability density
% pc(m)      probability density under component m

term1 = (2*pi)^(-0.5*jdm.D);

for m=1:jdm.M
    term2 = jdm.state(m).detC^(-0.5);
    e = u-jdm.state(m).m;
    term3 = exp(-e'*jdm.state(m).Lambda*e);
    pu = term1*term2*term3;
    
    pra = jdm.state(m).beta(r,a);
    pc(m) = pu*pra;
end
p = sum(pc);