function [tau] = jdm_generate (jdm,N)
% Generate N samples from Joint Density Model
% FORMAT [tau] = jdm_generate (jdm,N)
%
% jdm       data structure
% N         number of samples
%
% tau       inputs, actions and rewards
%           .u, .a, .r