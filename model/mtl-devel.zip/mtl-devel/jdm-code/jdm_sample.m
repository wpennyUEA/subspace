function [tau] = jdm_sample (jdm,N)
% Online learning of JDM 
% FORMAT [tau] = jdm_sample (jdm,N)
%
% jdm       data structure
% N         number of samples
%
% tau       .u,.a,.r samples

%ar_vec_vals=[1:jdm.R*jdm.K]';
%ar_vals=reshape(ar_vec_vals,jdm.R,jdm.K);

% For reading out r and a from joint density p(r,a|m)
r_vals=kron([1:jdm.R]',ones(1,jdm.K));
a_vals=kron(ones(jdm.R,1),[1:jdm.K]);
r_vec_vals=r_vals(:);
a_vec_vals=a_vals(:);

j = spm_multrnd(jdm.prior(:),N);
for m=1:jdm.M,
    C = inv(jdm.state(m).Lambda);
    state(m).u = spm_normrnd(jdm.state(m).m,C,N);
    beta = jdm.state(m).beta(:);
    state(m).ar = spm_multrnd(beta,N);
end

for n=1:N,
    m = j(n);
    tau.u(:,n) = state(m).u(:,n);
    tau.a(n) = a_vec_vals(state(m).ar(n));
    tau.r(n) = r_vec_vals(state(m).ar(n));
end
