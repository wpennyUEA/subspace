function [pv] = jdm_value (jdm,s,u)
% Compute reward probabilities
% FORMAT [pv] = jdm_value (jdm,s,u)
% 
% jdm       data structure
% s         task
% u         input stimulus
%       
% pv        [jdm.K x 1] vector of reward probabilities

if ~(s==1)
    disp('Warning: jdm_value.m not written for multitasks');
    return
end

% This is currently inefficient as Gauss likelihood 
% is unnecessarily computed lots of times
for k=1:jdm.K,
    for r=1:jdm.R,
        [p,pc]= jdm_like (jdm,u,k,r);
        pr(r,k) = p;
    end
end
pv=pr(2,:)./sum(pr); % r=2 for reward
pv=pv(:);
