function [jdm] = jdm_update (jdm,y)
% Update mixture model given new data point
% FORMAT [jdm] = jdm_update (jdm,y)
%
% jdm       mixture model data structure
% y         .u,.a,.r 

x = y.u;
d = y.a;
r = y.r;

for j=1:jdm.M,
    err(:,j) = x-jdm.state(j).m;
    d2(j) = err(:,j)'*jdm.state(j).Lambda*err(:,j);
end

if min(d2) > jdm.chi2
    jdm = jdm_create(jdm,y);
    return
end

like0=(2*pi)^(-jdm.D/2);

% Update Components
for j=1:jdm.M
    %like1 =dbquit
    like(j) = like0*(jdm.state(j).detC)^(-0.5)*exp(-0.5*d2(j));
    post(j) = jdm.prior(j)*like(j);
end
post=post/sum(post);

jdm.v = jdm.v+1;
jdm.sp = jdm.sp+post;
jdm.prior = jdm.sp/sum(jdm.sp); 
w=post./jdm.sp;

for j=1:jdm.M,
    dmu = w(j)*err(:,j);
    jdm.state(j).m = jdm.state(j).m + dmu;
    new_err = x-jdm.state(j).m;
    
    % Equation 20 in [1]
    Lambda = jdm.state(j).Lambda;
    w1 = 1-w(j);
    term1 = Lambda/w1;
    num = (w(j)/(w1^2)) * Lambda *new_err*new_err'*Lambda;
    denom1 = 1 + (w(j)/w1) * new_err'*Lambda*new_err;
    Lambda_bar = term1 - num/denom1;
    
    % Equation 21 in [1]
    num = Lambda_bar*dmu*dmu'*Lambda_bar;
    denom2 = 1 - dmu'*Lambda_bar*dmu;
    jdm.state(j).Lambda = Lambda_bar + num/denom2;
    
    % Equations 25 and 26 in [1]
    term1=(1-w(j))^jdm.D;
    Cbar = term1*jdm.state(j).detC*denom1;
    jdm.state(j).detC = Cbar*denom2;
    
    if jdm.state(j).detC < 0 
        disp('Error in igmm_update');
        disp('Increase s0 parameter');
        return
    end
    
    % Update decision and reward counts
    jdm.state(j).b(r,d)=jdm.state(j).b(r,d)+post(j);
end

