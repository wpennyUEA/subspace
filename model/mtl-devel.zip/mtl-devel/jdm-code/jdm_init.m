function [jdm] = jdm_init (jdm,y)
% Initialise Joint Density Model ready for online learning
% FORMAT [jdm] = jdm_init (jdm,y)
%
% jdm       Data structure
%           .s0  [1 x 1] initial standard deviation of Gaussian component
%           .p0  New cluster threshold (percentile of Chi^2 density)
%           .D   Dimension of input
%           .K   Number of discrete actions
%           .R   Number of discrete rewards (e.g. 2)
%
% y         First data point
%           .u        [D x 1] first input vector 
%           .a        [1 x 1] first decision 
%           .r        [1 x 1] first reward
%

jdm.M=0;            % Number of components

sig02=jdm.s0^2;
jdm.lambda0=1/(sig02);  % inverse sigma_ini
jdm.det0 = sig02^jdm.D;

% Chi^2 Threshold for creating new component
jdm.chi2 = spm_invXcdf(1-jdm.p0,jdm.D); 

% Dirichlet counts for decisions and rewards
jdm.b0=0.1*ones(jdm.R,jdm.K);

jdm = jdm_create(jdm,y);