function [] = plot_tau (tau)
% Plot Memory Buffer for 2D inputs
% FORMAT [] = plot_tau (tau)
%
% tau   .u,.a,.r inputs, actions and rewards

if any(tau.r==0)
    tau.r = tau.r + 1;
end
 
ind(1,1)=1;
ind(1,2)=2;
ind(2,1)=3;
ind(2,2)=4;
act=[1,1,2,2];
rew=[1,2,1,2];
sym={'ro','go','rx','gx'};
str={'a=1,r=0','a=1,r=1','a=2,r=0','a=2,r=1'};

for i=1:4,
    tmp=find(tau.a==act(i) & tau.r==rew(i));
    plot(tau.u(1,tmp),tau.u(2,tmp),sym{i});
    hold on
end
legend(str);
