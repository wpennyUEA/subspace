function [jdm] = jdm_test (jdm,task,test)
% Compute expected log likelihood of JDM on test set
% FORMAT [jdm] = jdm_test (mvl,task,test)
%
% jdm       data structure
% task      see e.g. rl_task_qlr
% test      .c, .u test set inputs
%
% jdm       .Lexp      expected log likelihood of reward at test
%           .pcexp     expected prob corr (per pattern likelihood) at test
%           

n=1;
Ntest=length(test.c);
for t=1:Ntest,
    ut=test.u(:,t);
    st=test.s(t);
    pvt = jdm_value (jdm,st,ut);
    a = rl_decide(pvt,1); 
    %a = spm_multrnd(pvt,1);
    [v,pr] = rl_task_reward(task{st},ut,a);
    ell(t) = pr*log(pvt(a)+eps)+(1-pr)*log(1-pvt(a)+eps);
end

jdm.Lexp=sum(ell);
jdm.pcexp=exp(jdm.Lexp/Ntest);

jdm.Lexp=sum(ell);
jdm.pcexp=exp(jdm.Lexp/Ntest);