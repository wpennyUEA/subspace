function [jdm] = igmm_create (jdm,y)
% Create new mixture component
% FORMAT [jdm] = igmm_create (jdm,y)
%
% jdm       mixture model data structure
% y         data point
%           .u        [D x 1] input vector 
%           .a        [1 x 1] decision 
%           .r        [1 x 1] reward (1 or 2 or ...)
%

jdm.M = jdm.M+1;
M = jdm.M;

jdm.state(M).m = y.u;
jdm.state(M).Lambda = jdm.lambda0*eye(jdm.D);
jdm.state(M).detC = jdm.det0;

jdm.sp(M) = 1;
jdm.v(M) = 1;
jdm.prior(M) = 1/sum(jdm.sp);

jdm.state(M).b=jdm.b0;
jdm.state(M).b(y.r,y.a)=jdm.state(M).b(y.r,y.a)+1;



