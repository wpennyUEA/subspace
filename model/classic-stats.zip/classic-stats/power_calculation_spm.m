
clear all
close all

% Parameter estimate (mean)
m=0.23;

% Parameter stderr
se=0.12;

% Number of subjects
N=59;

% significance level
alpha=0.05;

s = se*sqrt(N);

% Using stats toolbox function
% z_alpha=icdf('norm',1-alpha);

% Using SPM function
z_alpha=spm_invNcdf(1-alpha);

n=[30:1:200];
for i=1:length(n),
    sN=s/sqrt(n(i)); % standard error you would've got with n(i) subjects
    z_pow=m/sN;
    
    % Using stats toolbox
    %pow(i)=1-cdf('norm',z_alpha-z_pow);
    
    % Using SPM function
    pow(i)=1-spm_Ncdf(z_alpha-z_pow);
end

figure
plot(n,pow);
xlabel('Subjects');
ylabel('Power');
title(sprintf('Significance level = %1.2f',alpha));
grid on

ind=find(n==N);
powN=pow(ind);
disp('Power is the probability of rejecting the null given its false');
disp(sprintf('For N=%d, sig level=%1.2f, power is %1.2f',N,alpha,powN));


