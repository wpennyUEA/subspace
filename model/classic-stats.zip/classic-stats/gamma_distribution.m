
clear all
close all

mean=1;
var=0.2;

% mean = a * b
% variance = a * b^2

a=mean^2/var;
b=var/mean;

N=1000;
x = spm_gamrnd(a,b,N);

figure
hist(x,20);
grid on
xlabel('x');
set(gca,'YTickLabel',[]);
ylabel('p(x)');


